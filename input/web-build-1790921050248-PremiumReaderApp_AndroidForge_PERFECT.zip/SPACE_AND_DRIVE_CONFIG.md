# Space Requirements & C Drive Configuration

## 📊 Space Requirements Breakdown

### **Minimum Space Needed:**

1. **Project Files (Already on your drive):**
   - Source code: ~5-10 MB
   - Total: **~10 MB**

2. **JDK 17 Installation:**
   - Size: ~300-400 MB
   - Can install anywhere (doesn't need C drive)

3. **Gradle Cache (.gradle folder):**
   - Downloaded dependencies, build tools
   - Size: ~1-2 GB (first build)
   - Location: User home directory by default
   - **Can be redirected to any drive**

4. **Android SDK (optional):**
   - Basic SDK: ~3-5 GB
   - Full SDK: ~10-15 GB
   - **Can be installed on any drive**

5. **Build Output (APK):**
   - Debug APK: ~20-30 MB
   - Stays in project folder

### **Total Space Required:**
- **Without Android SDK**: ~1.5-2.5 GB (JDK + Gradle cache)
- **With Android SDK**: ~5-8 GB (JDK + Gradle + SDK)

---

## 🚫 How to AVOID Using C Drive

By default, Gradle uses `C:\Users\YourName\.gradle` for cache. Here's how to move everything to another drive:

### **Method 1: Environment Variables (Recommended)**

Set these environment variables to redirect to your preferred drive (e.g., D:, E:, etc.):

#### **Windows (PowerShell - Run as Administrator):**

```powershell
# Redirect Gradle cache to E drive (change E: to your preferred drive)
[System.Environment]::SetEnvironmentVariable('GRADLE_USER_HOME', 'E:\Gradle', 'User')

# Redirect Android SDK to E drive (if needed)
[System.Environment]::SetEnvironmentVariable('ANDROID_HOME', 'E:\Android\sdk', 'User')
[System.Environment]::SetEnvironmentVariable('ANDROID_SDK_ROOT', 'E:\Android\sdk', 'User')

# Redirect Java temp directory
[System.Environment]::SetEnvironmentVariable('JAVA_OPTS', '-Djava.io.tmpdir=E:\Temp', 'User')

# Verify settings
[System.Environment]::GetEnvironmentVariable('GRADLE_USER_HOME', 'User')
```

#### **After Setting Variables:**
1. Close all PowerShell/Command Prompt windows
2. Restart your computer (or log out and log back in)
3. Verify with: `echo %GRADLE_USER_HOME%`

---

### **Method 2: gradle.properties File (Alternative)**

Create or edit `gradle.properties` in your project root:

```properties
# Redirect Gradle cache to E drive
org.gradle.user.home=E:\\Gradle

# Redirect Java temp
org.gradle.jvmargs=-Xmx2048m -Djava.io.tmpdir=E:\\Temp
```

---

### **Method 3: local.properties File**

Create `local.properties` in project root to specify SDK location:

```properties
# Android SDK on E drive (change to your drive)
sdk.dir=E:\\Android\\sdk
```

---

## 🔧 Step-by-Step: Complete Setup on Non-C Drive

Here's a complete guide to keep EVERYTHING off your C drive:

### **Step 1: Install JDK 17 to Another Drive**

1. Download JDK 17 from https://adoptium.net/
2. During installation, change the path:
   - Default: `C:\Program Files\Eclipse Adoptium\jdk-17.0.x`
   - **Change to**: `E:\Java\jdk-17` (or your preferred drive)
3. Set JAVA_HOME:
   ```powershell
   setx JAVA_HOME "E:\Java\jdk-17"
   setx PATH "%PATH%;E:\Java\jdk-17\bin"
   ```

### **Step 2: Configure Gradle to Use Another Drive**

```powershell
# Set Gradle cache location
setx GRADLE_USER_HOME "E:\Gradle"
```

### **Step 3: Create local.properties**

In your `PremiumReaderApp` folder, create `local.properties`:

```properties
# If you need Android SDK, put it here
sdk.dir=E:\\Android\\sdk

# Additional Gradle settings
org.gradle.user.home=E:\\Gradle
```

### **Step 4: Create gradle.properties**

In your `PremiumReaderApp` folder, edit `gradle.properties`:

```properties
# Existing settings...
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8 -Djava.io.tmpdir=E:\\Temp
org.gradle.parallel=true
org.gradle.caching=true

# Redirect Gradle home
org.gradle.user.home=E:\\Gradle

# AndroidX
android.useAndroidX=true
kotlin.code.style=official
android.enableJetpackCompose=true
android.nonTransitiveRClass=true
```

### **Step 5: Build Your APK**

```cmd
cd E:\YourProjectFolder\PremiumReaderApp
.\gradlew.bat assembleDebug
```

Everything will now download to `E:\Gradle` instead of `C:\Users\YourName\.gradle`

---

## 📍 Where Files Will Be Stored

With the above configuration:

| What | Default Location (C Drive) | New Location (Your Drive) |
|------|---------------------------|---------------------------|
| Project files | Wherever you cloned | Same (your choice) |
| JDK 17 | `C:\Program Files\...` | `E:\Java\jdk-17` |
| Gradle cache | `C:\Users\Name\.gradle` | `E:\Gradle` |
| Android SDK | `C:\Users\Name\AppData\Local\Android\sdk` | `E:\Android\sdk` |
| Temp files | `C:\Users\Name\AppData\Local\Temp` | `E:\Temp` |
| Build output (APK) | Project folder | Project folder |

---

## 🎯 Minimal Setup (No Android SDK Needed)

If you just want to build the APK without installing the full Android SDK:

1. **Install JDK 17 to E drive** (300 MB)
2. **Set GRADLE_USER_HOME to E drive** (will use ~1.5 GB)
3. **Build** - Gradle will download only what's needed

**Total C drive usage: 0 MB** (everything on E drive)
**Total space needed: ~1.8 GB on E drive**

---

## ✅ Verify Your Setup

After configuration, check where Gradle will store files:

```cmd
echo %GRADLE_USER_HOME%
echo %ANDROID_HOME%
echo %JAVA_HOME%
```

Should show your E drive (or whichever drive you chose), not C drive.

---

## 🚨 Important Notes

1. **Environment variables require restart**: After setting with `setx`, restart your terminal or log out/in
2. **Use double backslashes** in properties files: `E:\\Gradle` not `E:\Gradle`
3. **Create folders first**: Make sure `E:\Gradle`, `E:\Temp`, etc. exist before building
4. **First build**: Will download ~1-2 GB to your configured location

---

## 💡 Quick Setup Script

Save this as `setup-non-c-drive.bat`:

```batch
@echo off
echo Setting up build environment on E: drive...
echo.

REM Create directories
mkdir E:\Gradle 2>nul
mkdir E:\Temp 2>nul
mkdir E:\Android 2>nul

REM Set environment variables
setx GRADLE_USER_HOME "E:\Gradle"
setx ANDROID_HOME "E:\Android\sdk"
setx ANDROID_SDK_ROOT "E:\Android\sdk"

echo.
echo ✓ Environment variables set!
echo ✓ Directories created on E: drive
echo.
echo IMPORTANT: Restart your computer for changes to take effect.
echo.
pause
```

Run this script, restart your computer, then build your APK. Everything will be on E drive!

---

## Summary

**Without configuration**: ~1.5 GB on C drive (Gradle cache in user folder)  
**With configuration**: **0 GB on C drive** (everything on your chosen drive)  
**Time to configure**: ~5 minutes  
**Worth it**: Absolutely! ✓
