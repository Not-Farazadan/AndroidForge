# HOW TO RUN POWERSHELL SCRIPTS

## The Problem
Your folder path has special characters (&) that break batch (.bat) files.
PowerShell handles these much better!

## Solution: Run PowerShell Scripts

### Method 1: Right-Click Method (EASIEST)

1. Find the file: `diagnose.ps1` in File Explorer
2. **Right-click** on it
3. Select **"Run with PowerShell"**
4. That's it! Window stays open automatically.

### Method 2: From PowerShell Window

1. Open File Explorer
2. Navigate to: E:\Noxa - Ebook & Audio Book\Claude Code\PremiumReaderApp
3. Click on the address bar (where the path shows)
4. Type: `powershell`
5. Press Enter
6. Type: `.\diagnose.ps1`
7. Press Enter

### Method 3: From Run Dialog

1. Press `Win + R`
2. Paste this:
   ```
   powershell -NoExit -ExecutionPolicy Bypass -File "E:\Noxa - Ebook & Audio Book\Claude Code\PremiumReaderApp\diagnose.ps1"
   ```
3. Press Enter

## If You Get "Execution Policy" Error

If you see an error about execution policy, do this:

1. Right-click on PowerShell (search for it in Start menu)
2. Select "Run as Administrator"
3. Type: `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser`
4. Press Enter
5. Type: `Y` and press Enter
6. Close PowerShell
7. Now try running the script again

## Files to Run

### To Check Setup:
- **Right-click** `diagnose.ps1` → **Run with PowerShell**

### To Build APK:
- **Right-click** `build-apk.ps1` → **Run with PowerShell**

## Why PowerShell?

- ✅ Handles special characters (&, spaces) properly
- ✅ Better error messages
- ✅ Colored output (easier to read)
- ✅ Window stays open automatically
- ✅ More reliable than batch files

## Quick Summary

**Just right-click `diagnose.ps1` and select "Run with PowerShell"**

That's the easiest way! 🚀
