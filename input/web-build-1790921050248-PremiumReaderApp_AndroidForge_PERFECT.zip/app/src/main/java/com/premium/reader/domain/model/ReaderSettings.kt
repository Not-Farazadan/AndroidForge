package com.premium.reader.domain.model

data class ReaderSettings(
    val fontFamily: FontFamily = FontFamily.SERIF_DEFAULT,
    val fontSize: Int = 16,
    val lineSpacing: LineSpacing = LineSpacing.NORMAL,
    val textAlignment: TextAlignment = TextAlignment.JUSTIFY,
    val theme: ReaderTheme = ReaderTheme.LIGHT
)

enum class FontFamily(val displayName: String, val fontName: String) {
    SERIF_DEFAULT("Serif", "serif"),
    SERIF_GEORGIA("Georgia", "serif"),
    SERIF_TIMES("Times New Roman", "serif"),
    SERIF_PALATINO("Palatino", "serif"),
    SANS_ROBOTO("Roboto", "sans-serif"),
    SANS_OPEN_SANS("Open Sans", "sans-serif"),
    SANS_LATO("Lato", "sans-serif")
}

enum class LineSpacing(val displayName: String, val multiplier: Float) {
    TIGHT("Tight", 1.0f),
    NORMAL("Normal", 1.3f),
    RELAXED("Relaxed", 1.6f),
    EXTRA_RELAXED("Extra Relaxed", 1.9f)
}

enum class TextAlignment(val displayName: String) {
    LEFT("Left"),
    CENTER("Center"),
    JUSTIFY("Justify")
}

enum class ReaderTheme(val displayName: String) {
    LIGHT("Light"),
    DARK("Dark"),
    SEPIA("Sepia")
}
