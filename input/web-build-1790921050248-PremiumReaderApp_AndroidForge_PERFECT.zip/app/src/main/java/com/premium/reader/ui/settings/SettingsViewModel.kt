package com.premium.reader.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.premium.reader.domain.model.*
import com.premium.reader.domain.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    val audioSettings: StateFlow<AudioSettings> = preferencesRepository.getAudioSettings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AudioSettings()
        )

    val readerSettings: StateFlow<ReaderSettings> = preferencesRepository.getReaderSettings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ReaderSettings()
        )

    fun updateTtsVoice(voice: TtsVoice) {
        viewModelScope.launch {
            val current = audioSettings.value
            preferencesRepository.updateAudioSettings(current.copy(ttsVoice = voice))
        }
    }

    fun updatePlaybackSpeed(speed: Float) {
        viewModelScope.launch {
            val current = audioSettings.value
            preferencesRepository.updateAudioSettings(current.copy(playbackSpeed = speed))
        }
    }

    fun updateAutoPlayNext(autoPlay: Boolean) {
        viewModelScope.launch {
            val current = audioSettings.value
            preferencesRepository.updateAudioSettings(current.copy(autoPlayNextChapter = autoPlay))
        }
    }

    fun updateFontFamily(fontFamily: FontFamily) {
        viewModelScope.launch {
            val current = readerSettings.value
            preferencesRepository.updateReaderSettings(current.copy(fontFamily = fontFamily))
        }
    }

    fun updateFontSize(size: Int) {
        viewModelScope.launch {
            val current = readerSettings.value
            preferencesRepository.updateReaderSettings(current.copy(fontSize = size))
        }
    }

    fun updateTheme(theme: ReaderTheme) {
        viewModelScope.launch {
            val current = readerSettings.value
            preferencesRepository.updateReaderSettings(current.copy(theme = theme))
        }
    }
}
