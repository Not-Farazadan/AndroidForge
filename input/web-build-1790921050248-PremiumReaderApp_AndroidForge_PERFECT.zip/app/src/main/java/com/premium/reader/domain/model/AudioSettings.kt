package com.premium.reader.domain.model

data class AudioSettings(
    val ttsVoice: TtsVoice = TtsVoice.AVA,
    val playbackSpeed: Float = 1.0f,
    val autoPlayNextChapter: Boolean = true
)

enum class TtsVoice(val displayName: String, val voiceId: String) {
    AVA("Ava (Female)", "en-US-AvaMultilingualNeural"),
    RYAN("Ryan (Male)", "en-US-RyanMultilingualNeural")
}
