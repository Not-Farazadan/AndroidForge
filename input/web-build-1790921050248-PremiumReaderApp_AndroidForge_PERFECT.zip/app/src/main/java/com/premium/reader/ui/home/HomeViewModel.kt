package com.premium.reader.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.premium.reader.domain.model.Book
import com.premium.reader.domain.repository.BookRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val ebooks: List<Book> = emptyList(),
    val audiobooks: List<Book> = emptyList(),
    val lastReadEbook: Book? = null,
    val lastReadAudiobook: Book? = null,
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val bookRepository: BookRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadBooks()
        loadSampleContent()
    }

    private fun loadBooks() {
        viewModelScope.launch {
            try {
                combine(
                    bookRepository.getEbooks(),
                    bookRepository.getAudiobooks(),
                    bookRepository.getLastReadEbook(),
                    bookRepository.getLastReadAudiobook()
                ) { ebooks, audiobooks, lastEbook, lastAudiobook ->
                    HomeUiState(
                        ebooks = ebooks,
                        audiobooks = audiobooks,
                        lastReadEbook = lastEbook,
                        lastReadAudiobook = lastAudiobook,
                        isLoading = false,
                        error = null
                    )
                }.collect { state ->
                    _uiState.value = state
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Unknown error occurred"
                )
            }
        }
    }

    private fun loadSampleContent() {
        viewModelScope.launch {
            try {
                // Check if we already have content
                val hasEbooks = _uiState.value.ebooks.isNotEmpty()
                val hasAudiobooks = _uiState.value.audiobooks.isNotEmpty()

                if (!hasEbooks && !hasAudiobooks) {
                    bookRepository.loadSampleContent()
                }
            } catch (e: Exception) {
                // Silently fail - sample content is optional
            }
        }
    }

    fun retry() {
        _uiState.value = HomeUiState(isLoading = true)
        loadBooks()
    }
}
