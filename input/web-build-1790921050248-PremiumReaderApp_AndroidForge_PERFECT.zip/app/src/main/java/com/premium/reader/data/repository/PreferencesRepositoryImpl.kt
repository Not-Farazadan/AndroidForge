package com.premium.reader.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.premium.reader.domain.model.*
import com.premium.reader.domain.repository.PreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "reader_preferences")

@Singleton
class PreferencesRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : PreferencesRepository {

    private object PreferencesKeys {
        // Reader settings
        val FONT_FAMILY = stringPreferencesKey("font_family")
        val FONT_SIZE = intPreferencesKey("font_size")
        val LINE_SPACING = stringPreferencesKey("line_spacing")
        val TEXT_ALIGNMENT = stringPreferencesKey("text_alignment")
        val READER_THEME = stringPreferencesKey("reader_theme")

        // Audio settings
        val TTS_VOICE = stringPreferencesKey("tts_voice")
        val PLAYBACK_SPEED = floatPreferencesKey("playback_speed")
        val AUTO_PLAY_NEXT = booleanPreferencesKey("auto_play_next")
    }

    override fun getReaderSettings(): Flow<ReaderSettings> {
        return context.dataStore.data
            .catch { exception ->
                if (exception is IOException) {
                    emit(emptyPreferences())
                } else {
                    throw exception
                }
            }
            .map { preferences ->
                ReaderSettings(
                    fontFamily = preferences[PreferencesKeys.FONT_FAMILY]?.let {
                        FontFamily.valueOf(it)
                    } ?: FontFamily.SERIF_DEFAULT,
                    fontSize = preferences[PreferencesKeys.FONT_SIZE] ?: 16,
                    lineSpacing = preferences[PreferencesKeys.LINE_SPACING]?.let {
                        LineSpacing.valueOf(it)
                    } ?: LineSpacing.NORMAL,
                    textAlignment = preferences[PreferencesKeys.TEXT_ALIGNMENT]?.let {
                        TextAlignment.valueOf(it)
                    } ?: TextAlignment.JUSTIFY,
                    theme = preferences[PreferencesKeys.READER_THEME]?.let {
                        ReaderTheme.valueOf(it)
                    } ?: ReaderTheme.LIGHT
                )
            }
    }

    override suspend fun updateReaderSettings(settings: ReaderSettings) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.FONT_FAMILY] = settings.fontFamily.name
            preferences[PreferencesKeys.FONT_SIZE] = settings.fontSize
            preferences[PreferencesKeys.LINE_SPACING] = settings.lineSpacing.name
            preferences[PreferencesKeys.TEXT_ALIGNMENT] = settings.textAlignment.name
            preferences[PreferencesKeys.READER_THEME] = settings.theme.name
        }
    }

    override fun getAudioSettings(): Flow<AudioSettings> {
        return context.dataStore.data
            .catch { exception ->
                if (exception is IOException) {
                    emit(emptyPreferences())
                } else {
                    throw exception
                }
            }
            .map { preferences ->
                AudioSettings(
                    ttsVoice = preferences[PreferencesKeys.TTS_VOICE]?.let {
                        TtsVoice.valueOf(it)
                    } ?: TtsVoice.AVA,
                    playbackSpeed = preferences[PreferencesKeys.PLAYBACK_SPEED] ?: 1.0f,
                    autoPlayNextChapter = preferences[PreferencesKeys.AUTO_PLAY_NEXT] ?: true
                )
            }
    }

    override suspend fun updateAudioSettings(settings: AudioSettings) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.TTS_VOICE] = settings.ttsVoice.name
            preferences[PreferencesKeys.PLAYBACK_SPEED] = settings.playbackSpeed
            preferences[PreferencesKeys.AUTO_PLAY_NEXT] = settings.autoPlayNextChapter
        }
    }
}
