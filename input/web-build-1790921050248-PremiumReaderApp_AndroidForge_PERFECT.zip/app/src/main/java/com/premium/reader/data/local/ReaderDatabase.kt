package com.premium.reader.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.premium.reader.data.local.dao.BookDao
import com.premium.reader.data.local.dao.BookmarkDao
import com.premium.reader.data.local.entity.BookEntity
import com.premium.reader.data.local.entity.BookmarkEntity

@Database(
    entities = [BookEntity::class, BookmarkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ReaderDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao
    abstract fun bookmarkDao(): BookmarkDao
}
