package com.premium.reader.domain.model

data class Book(
    val id: String,
    val title: String,
    val author: String,
    val description: String,
    val coverPath: String,
    val filePath: String,
    val type: BookType,
    val totalPages: Int = 0,
    val totalDuration: Long = 0,
    val currentPage: Int = 0,
    val currentPosition: Long = 0,
    val progress: Float = 0f,
    val lastReadTimestamp: Long = 0,
    val isCompleted: Boolean = false,
    val chapters: List<Chapter> = emptyList()
)

enum class BookType {
    EBOOK, AUDIOBOOK
}

data class Chapter(
    val title: String,
    val startPage: Int = 0,
    val startPosition: Long = 0
)
