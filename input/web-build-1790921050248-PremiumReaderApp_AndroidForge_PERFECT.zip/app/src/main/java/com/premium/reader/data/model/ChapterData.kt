package com.premium.reader.data.model

import kotlinx.serialization.Serializable

@Serializable
data class ChapterData(
    val title: String,
    val startPage: Int = 0,
    val startPosition: Long = 0
)
