package com.premium.reader.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.premium.reader.domain.model.*
import com.premium.reader.domain.repository.BookRepository
import com.premium.reader.domain.repository.BookmarkRepository
import com.premium.reader.domain.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AudioPlayerUiState(
    val book: Book? = null,
    val isLoading: Boolean = true,
    val error: String? = null
)

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0,
    val duration: Long = 0,
    val playbackSpeed: Float = 1.0f,
    val currentChapterIndex: Int = 0
)

@HiltViewModel
class AudioPlayerViewModel @Inject constructor(
    private val bookRepository: BookRepository,
    private val bookmarkRepository: BookmarkRepository,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AudioPlayerUiState())
    val uiState: StateFlow<AudioPlayerUiState> = _uiState.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private var currentBookId: String? = null
    private var playbackJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        loadAudioSettings()
    }

    private fun loadAudioSettings() {
        viewModelScope.launch {
            preferencesRepository.getAudioSettings().collect { settings ->
                _playbackState.value = _playbackState.value.copy(
                    playbackSpeed = settings.playbackSpeed
                )
            }
        }
    }

    fun loadBook(bookId: String) {
        currentBookId = bookId
        viewModelScope.launch {
            try {
                bookRepository.getBookById(bookId).collect { book ->
                    if (book != null) {
                        _uiState.value = _uiState.value.copy(
                            book = book,
                            isLoading = false,
                            error = null
                        )

                        _playbackState.value = _playbackState.value.copy(
                            currentPosition = book.currentPosition,
                            duration = book.totalDuration,
                            currentChapterIndex = getCurrentChapterIndex(book.currentPosition, book.chapters)
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load audiobook"
                )
            }
        }
    }

    fun togglePlayPause() {
        val isPlaying = _playbackState.value.isPlaying
        _playbackState.value = _playbackState.value.copy(isPlaying = !isPlaying)

        if (!isPlaying) {
            startPlayback()
        } else {
            stopPlayback()
        }
    }

    private fun startPlayback() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (_playbackState.value.isPlaying) {
                delay(100)
                val currentPosition = _playbackState.value.currentPosition
                val speed = _playbackState.value.playbackSpeed
                val newPosition = (currentPosition + (100 * speed)).toLong()

                if (newPosition >= _playbackState.value.duration) {
                    // End of audiobook
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPosition = _playbackState.value.duration
                    )
                    updateProgress(_playbackState.value.duration)
                } else {
                    _playbackState.value = _playbackState.value.copy(
                        currentPosition = newPosition
                    )
                }
            }
        }
    }

    private fun stopPlayback() {
        playbackJob?.cancel()
        updateProgress(_playbackState.value.currentPosition)
    }

    fun seekTo(position: Long) {
        val book = _uiState.value.book ?: return
        val clampedPosition = position.coerceIn(0, book.totalDuration)

        _playbackState.value = _playbackState.value.copy(
            currentPosition = clampedPosition,
            currentChapterIndex = getCurrentChapterIndex(clampedPosition, book.chapters)
        )

        updateProgress(clampedPosition)
    }

    fun skipForward() {
        val currentPosition = _playbackState.value.currentPosition
        seekTo(currentPosition + 30000) // 30 seconds
    }

    fun skipBackward() {
        val currentPosition = _playbackState.value.currentPosition
        seekTo(currentPosition - 30000) // 30 seconds
    }

    fun nextChapter() {
        val book = _uiState.value.book ?: return
        val chapters = book.chapters
        if (chapters.isEmpty()) return

        val currentIndex = _playbackState.value.currentChapterIndex
        if (currentIndex < chapters.size - 1) {
            seekTo(chapters[currentIndex + 1].startPosition)
        }
    }

    fun previousChapter() {
        val book = _uiState.value.book ?: return
        val chapters = book.chapters
        if (chapters.isEmpty()) return

        val currentIndex = _playbackState.value.currentChapterIndex
        if (currentIndex > 0) {
            seekTo(chapters[currentIndex - 1].startPosition)
        } else {
            seekTo(0)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackState.value = _playbackState.value.copy(playbackSpeed = speed)

        viewModelScope.launch {
            preferencesRepository.getAudioSettings().first().let { settings ->
                preferencesRepository.updateAudioSettings(settings.copy(playbackSpeed = speed))
            }
        }
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()

        if (minutes > 0) {
            sleepTimerJob = viewModelScope.launch {
                delay(minutes * 60 * 1000L)
                if (_playbackState.value.isPlaying) {
                    togglePlayPause()
                }
            }
        } else if (minutes == -1) {
            // End of chapter
            val book = _uiState.value.book ?: return
            val chapters = book.chapters
            if (chapters.isEmpty()) return

            val currentIndex = _playbackState.value.currentChapterIndex
            if (currentIndex < chapters.size - 1) {
                val nextChapterStart = chapters[currentIndex + 1].startPosition
                val currentPosition = _playbackState.value.currentPosition
                val timeUntilNextChapter = nextChapterStart - currentPosition

                sleepTimerJob = viewModelScope.launch {
                    delay(timeUntilNextChapter)
                    if (_playbackState.value.isPlaying) {
                        togglePlayPause()
                    }
                }
            }
        }
    }

    fun addBookmark() {
        val book = _uiState.value.book ?: return
        val currentPosition = _playbackState.value.currentPosition
        val currentChapterIndex = _playbackState.value.currentChapterIndex

        viewModelScope.launch {
            val chapterTitle = if (book.chapters.isNotEmpty() && currentChapterIndex < book.chapters.size) {
                book.chapters[currentChapterIndex].title
            } else {
                "Position ${formatTime(currentPosition)}"
            }

            val bookmark = Bookmark(
                bookId = book.id,
                page = 0,
                position = currentPosition,
                chapterTitle = chapterTitle,
                note = ""
            )
            bookmarkRepository.addBookmark(bookmark)
        }
    }

    private fun updateProgress(position: Long) {
        val book = _uiState.value.book ?: return
        val progress = position.toFloat() / book.totalDuration.toFloat()

        viewModelScope.launch {
            bookRepository.updateProgress(
                bookId = book.id,
                page = 0,
                position = position,
                progress = progress
            )
        }
    }

    private fun getCurrentChapterIndex(position: Long, chapters: List<Chapter>): Int {
        if (chapters.isEmpty()) return 0

        for (i in chapters.indices.reversed()) {
            if (position >= chapters[i].startPosition) {
                return i
            }
        }
        return 0
    }

    private fun formatTime(milliseconds: Long): String {
        val totalSeconds = (milliseconds / 1000).toInt()
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        sleepTimerJob?.cancel()
        stopPlayback()
    }
}
