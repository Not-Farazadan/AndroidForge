package com.premium.reader.data.model

import com.premium.reader.data.local.entity.BookEntity
import com.premium.reader.data.local.entity.BookmarkEntity
import com.premium.reader.domain.model.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString

private val json = Json { ignoreUnknownKeys = true }

fun BookEntity.toDomain(): Book {
    val chapters = try {
        if (chapterData.isNotEmpty()) {
            json.decodeFromString<List<Chapter>>(chapterData)
        } else {
            emptyList()
        }
    } catch (e: Exception) {
        emptyList()
    }

    return Book(
        id = id,
        title = title,
        author = author,
        description = description,
        coverPath = coverPath,
        filePath = filePath,
        type = if (type == "ebook") BookType.EBOOK else BookType.AUDIOBOOK,
        totalPages = totalPages,
        totalDuration = totalDuration,
        currentPage = currentPage,
        currentPosition = currentPosition,
        progress = progress,
        lastReadTimestamp = lastReadTimestamp,
        isCompleted = isCompleted,
        chapters = chapters
    )
}

fun Book.toEntity(): BookEntity {
    val chapterDataJson = try {
        if (chapters.isNotEmpty()) {
            json.encodeToString(chapters)
        } else {
            ""
        }
    } catch (e: Exception) {
        ""
    }

    return BookEntity(
        id = id,
        title = title,
        author = author,
        description = description,
        coverPath = coverPath,
        filePath = filePath,
        type = if (type == BookType.EBOOK) "ebook" else "audiobook",
        totalPages = totalPages,
        totalDuration = totalDuration,
        currentPage = currentPage,
        currentPosition = currentPosition,
        progress = progress,
        lastReadTimestamp = lastReadTimestamp,
        isCompleted = isCompleted,
        chapterData = chapterDataJson
    )
}

fun BookmarkEntity.toDomain(): Bookmark {
    return Bookmark(
        id = id,
        bookId = bookId,
        page = page,
        position = position,
        chapterTitle = chapterTitle,
        note = note,
        timestamp = timestamp
    )
}

fun Bookmark.toEntity(): BookmarkEntity {
    return BookmarkEntity(
        id = id,
        bookId = bookId,
        page = page,
        position = position,
        chapterTitle = chapterTitle,
        note = note,
        timestamp = timestamp
    )
}
