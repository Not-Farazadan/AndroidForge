package com.premium.reader.domain.model

data class Bookmark(
    val id: Long = 0,
    val bookId: String,
    val page: Int = 0,
    val position: Long = 0,
    val chapterTitle: String = "",
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
