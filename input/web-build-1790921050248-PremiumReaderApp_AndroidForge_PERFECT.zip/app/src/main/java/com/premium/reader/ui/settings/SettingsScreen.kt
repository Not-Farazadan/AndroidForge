package com.premium.reader.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.premium.reader.BuildConfig
import com.premium.reader.R
import com.premium.reader.domain.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val audioSettings by viewModel.audioSettings.collectAsState()
    val readerSettings by viewModel.readerSettings.collectAsState()

    var showVoiceDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showFontDialog by remember { mutableStateOf(false) }
    var showFontSizeDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // Audiobook Settings
            SettingsSection(title = stringResource(R.string.audiobook_settings))

            SettingsItem(
                title = stringResource(R.string.tts_voice),
                subtitle = audioSettings.ttsVoice.displayName,
                onClick = { showVoiceDialog = true }
            )

            SettingsItem(
                title = stringResource(R.string.default_playback_speed),
                subtitle = "${audioSettings.playbackSpeed}x",
                onClick = { showSpeedDialog = true }
            )

            SettingsSwitchItem(
                title = stringResource(R.string.auto_play_next_chapter),
                checked = audioSettings.autoPlayNextChapter,
                onCheckedChange = {
                    viewModel.updateAutoPlayNext(it)
                }
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // Reading Settings
            SettingsSection(title = stringResource(R.string.reading_settings_section))

            SettingsItem(
                title = stringResource(R.string.default_font),
                subtitle = readerSettings.fontFamily.displayName,
                onClick = { showFontDialog = true }
            )

            SettingsItem(
                title = stringResource(R.string.default_font_size),
                subtitle = "${readerSettings.fontSize}sp",
                onClick = { showFontSizeDialog = true }
            )

            SettingsItem(
                title = stringResource(R.string.default_theme),
                subtitle = readerSettings.theme.displayName,
                onClick = { showThemeDialog = true }
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // General
            SettingsSection(title = stringResource(R.string.general))

            SettingsItem(
                title = stringResource(R.string.version),
                subtitle = BuildConfig.VERSION_NAME,
                onClick = null
            )

            SettingsItem(
                title = stringResource(R.string.about),
                subtitle = "Premium Reader - A beautiful reading experience",
                onClick = null
            )
        }
    }

    // Dialogs
    if (showVoiceDialog) {
        VoiceSelectionDialog(
            currentVoice = audioSettings.ttsVoice,
            onDismiss = { showVoiceDialog = false },
            onVoiceSelected = {
                viewModel.updateTtsVoice(it)
                showVoiceDialog = false
            }
        )
    }

    if (showSpeedDialog) {
        SpeedSelectionDialog(
            currentSpeed = audioSettings.playbackSpeed,
            onDismiss = { showSpeedDialog = false },
            onSpeedSelected = {
                viewModel.updatePlaybackSpeed(it)
                showSpeedDialog = false
            }
        )
    }

    if (showFontDialog) {
        FontFamilyDialog(
            currentFont = readerSettings.fontFamily,
            onDismiss = { showFontDialog = false },
            onFontSelected = {
                viewModel.updateFontFamily(it)
                showFontDialog = false
            }
        )
    }

    if (showFontSizeDialog) {
        FontSizeDialog(
            currentSize = readerSettings.fontSize,
            onDismiss = { showFontSizeDialog = false },
            onSizeSelected = {
                viewModel.updateFontSize(it)
                showFontSizeDialog = false
            }
        )
    }

    if (showThemeDialog) {
        ThemeDialog(
            currentTheme = readerSettings.theme,
            onDismiss = { showThemeDialog = false },
            onThemeSelected = {
                viewModel.updateTheme(it)
                showThemeDialog = false
            }
        )
    }
}

@Composable
private fun SettingsSection(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
private fun SettingsItem(
    title: String,
    subtitle: String,
    onClick: (() -> Unit)?
) {
    val modifier = if (onClick != null) {
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    } else {
        Modifier.fillMaxWidth()
    }

    Column(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingsSwitchItem(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
private fun VoiceSelectionDialog(
    currentVoice: TtsVoice,
    onDismiss: () -> Unit,
    onVoiceSelected: (TtsVoice) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.tts_voice)) },
        text = {
            Column {
                TtsVoice.entries.forEach { voice ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onVoiceSelected(voice) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = voice == currentVoice,
                            onClick = { onVoiceSelected(voice) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(voice.displayName)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun SpeedSelectionDialog(
    currentSpeed: Float,
    onDismiss: () -> Unit,
    onSpeedSelected: (Float) -> Unit
) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.playback_speed)) },
        text = {
            Column {
                speeds.forEach { speed ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSpeedSelected(speed) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = speed == currentSpeed,
                            onClick = { onSpeedSelected(speed) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${speed}x")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun FontFamilyDialog(
    currentFont: FontFamily,
    onDismiss: () -> Unit,
    onFontSelected: (FontFamily) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.font_family)) },
        text = {
            Column {
                FontFamily.entries.forEach { font ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onFontSelected(font) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = font == currentFont,
                            onClick = { onFontSelected(font) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(font.displayName)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun FontSizeDialog(
    currentSize: Int,
    onDismiss: () -> Unit,
    onSizeSelected: (Int) -> Unit
) {
    val sizes = listOf(12, 14, 16, 18, 20, 22, 24, 28)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.font_size)) },
        text = {
            Column {
                sizes.forEach { size ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSizeSelected(size) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = size == currentSize,
                            onClick = { onSizeSelected(size) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${size}sp")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun ThemeDialog(
    currentTheme: ReaderTheme,
    onDismiss: () -> Unit,
    onThemeSelected: (ReaderTheme) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.theme)) },
        text = {
            Column {
                ReaderTheme.entries.forEach { theme ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onThemeSelected(theme) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = theme == currentTheme,
                            onClick = { onThemeSelected(theme) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(theme.displayName)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}
