package com.premium.reader.domain.repository

import com.premium.reader.domain.model.*
import kotlinx.coroutines.flow.Flow

interface BookRepository {
    fun getEbooks(): Flow<List<Book>>
    fun getAudiobooks(): Flow<List<Book>>
    fun getBookById(bookId: String): Flow<Book?>
    suspend fun getBookByIdSync(bookId: String): Book?
    fun getLastReadEbook(): Flow<Book?>
    fun getLastReadAudiobook(): Flow<Book?>
    suspend fun insertBook(book: Book)
    suspend fun updateBook(book: Book)
    suspend fun updateProgress(bookId: String, page: Int, position: Long, progress: Float)
    suspend fun deleteBook(bookId: String)
    suspend fun loadSampleContent()
}
