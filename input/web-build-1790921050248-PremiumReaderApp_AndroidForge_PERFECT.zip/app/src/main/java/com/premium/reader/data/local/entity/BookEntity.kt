package com.premium.reader.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val author: String,
    val description: String,
    val coverPath: String,
    val filePath: String,
    val type: String, // "ebook" or "audiobook"
    val totalPages: Int = 0, // For ebooks
    val totalDuration: Long = 0, // For audiobooks in milliseconds
    val currentPage: Int = 0,
    val currentPosition: Long = 0, // For audiobooks in milliseconds
    val progress: Float = 0f, // 0.0 to 1.0
    val lastReadTimestamp: Long = 0,
    val isCompleted: Boolean = false,
    val chapterData: String = "", // JSON string of chapters
    val metadata: String = "" // JSON string of additional metadata
)
