package com.premium.reader.ui.reader

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.premium.reader.domain.model.*
import com.premium.reader.domain.repository.BookRepository
import com.premium.reader.domain.repository.BookmarkRepository
import com.premium.reader.domain.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EbookReaderUiState(
    val book: Book? = null,
    val currentPage: Int = 1,
    val currentPageContent: String? = null,
    val bookmarks: List<Bookmark> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class EbookReaderViewModel @Inject constructor(
    private val bookRepository: BookRepository,
    private val bookmarkRepository: BookmarkRepository,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(EbookReaderUiState())
    val uiState: StateFlow<EbookReaderUiState> = _uiState.asStateFlow()

    val settings: StateFlow<ReaderSettings> = preferencesRepository.getReaderSettings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ReaderSettings()
        )

    private var currentBookId: String? = null
    private val pageContents = mutableListOf<String>()

    fun loadBook(bookId: String) {
        currentBookId = bookId
        viewModelScope.launch {
            try {
                bookRepository.getBookById(bookId).collect { book ->
                    if (book != null) {
                        _uiState.value = _uiState.value.copy(
                            book = book,
                            isLoading = false,
                            error = null
                        )

                        // Load page content (simulated)
                        loadPageContent(book.currentPage.coerceAtLeast(1))

                        // Load bookmarks
                        bookmarkRepository.getBookmarksForBook(bookId).collect { bookmarks ->
                            _uiState.value = _uiState.value.copy(bookmarks = bookmarks)
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load book"
                )
            }
        }
    }

    private fun loadPageContent(page: Int) {
        // In a real app, this would parse EPUB and extract page content
        // For now, we'll simulate with sample text
        val sampleText = generateSamplePageContent(page)
        _uiState.value = _uiState.value.copy(
            currentPage = page,
            currentPageContent = sampleText
        )
    }

    private fun generateSamplePageContent(page: Int): String {
        return """
            This is page $page of the book.

            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

            Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.

            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.
        """.trimIndent()
    }

    fun nextPage() {
        val book = _uiState.value.book ?: return
        val currentPage = _uiState.value.currentPage
        if (currentPage < book.totalPages) {
            val newPage = currentPage + 1
            loadPageContent(newPage)
            updateProgress(newPage)
        }
    }

    fun previousPage() {
        val currentPage = _uiState.value.currentPage
        if (currentPage > 1) {
            val newPage = currentPage - 1
            loadPageContent(newPage)
            updateProgress(newPage)
        }
    }

    fun goToPage(page: Int) {
        val book = _uiState.value.book ?: return
        if (page in 1..book.totalPages) {
            loadPageContent(page)
            updateProgress(page)
        }
    }

    private fun updateProgress(page: Int) {
        val book = _uiState.value.book ?: return
        val progress = page.toFloat() / book.totalPages.toFloat()

        viewModelScope.launch {
            bookRepository.updateProgress(
                bookId = book.id,
                page = page,
                position = 0,
                progress = progress
            )
        }
    }

    fun addBookmark() {
        val book = _uiState.value.book ?: return
        val currentPage = _uiState.value.currentPage

        viewModelScope.launch {
            val bookmark = Bookmark(
                bookId = book.id,
                page = currentPage,
                position = 0,
                chapterTitle = "Chapter ${currentPage / 10 + 1}",
                note = "Page $currentPage"
            )
            bookmarkRepository.addBookmark(bookmark)
        }
    }

    fun updateFontFamily(fontFamily: FontFamily) {
        viewModelScope.launch {
            val current = settings.value
            preferencesRepository.updateReaderSettings(current.copy(fontFamily = fontFamily))
        }
    }

    fun updateFontSize(size: Int) {
        viewModelScope.launch {
            val current = settings.value
            preferencesRepository.updateReaderSettings(current.copy(fontSize = size))
        }
    }

    fun updateLineSpacing(lineSpacing: LineSpacing) {
        viewModelScope.launch {
            val current = settings.value
            preferencesRepository.updateReaderSettings(current.copy(lineSpacing = lineSpacing))
        }
    }

    fun updateTextAlignment(alignment: TextAlignment) {
        viewModelScope.launch {
            val current = settings.value
            preferencesRepository.updateReaderSettings(current.copy(textAlignment = alignment))
        }
    }

    fun updateTheme(theme: ReaderTheme) {
        viewModelScope.launch {
            val current = settings.value
            preferencesRepository.updateReaderSettings(current.copy(theme = theme))
        }
    }
}
