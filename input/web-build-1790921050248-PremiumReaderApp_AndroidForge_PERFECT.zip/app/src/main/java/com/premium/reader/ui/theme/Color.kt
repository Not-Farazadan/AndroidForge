package com.premium.reader.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Deep Blue
val PrimaryLight = Color(0xFF1565C0)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD3E4F6)
val OnPrimaryContainerLight = Color(0xFF001D36)

val PrimaryDark = Color(0xFFA2C8EC)
val OnPrimaryDark = Color(0xFF003258)
val PrimaryContainerDark = Color(0xFF00497C)
val OnPrimaryContainerDark = Color(0xFFD3E4F6)

// Secondary Colors
val SecondaryLight = Color(0xFF535F70)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD7E3F7)
val OnSecondaryContainerLight = Color(0xFF101C2B)

val SecondaryDark = Color(0xFFBBC7DB)
val OnSecondaryDark = Color(0xFF253140)
val SecondaryContainerDark = Color(0xFF3C4858)
val OnSecondaryContainerDark = Color(0xFFD7E3F7)

// Background Colors
val BackgroundLight = Color(0xFFFDFCFF)
val OnBackgroundLight = Color(0xFF1A1C1E)
val SurfaceLight = Color(0xFFFDFCFF)
val OnSurfaceLight = Color(0xFF1A1C1E)

val BackgroundDark = Color(0xFF1A1C1E)
val OnBackgroundDark = Color(0xFFE2E2E5)
val SurfaceDark = Color(0xFF1A1C1E)
val OnSurfaceDark = Color(0xFFE2E2E5)

// Reader Theme Colors
val ReaderLightBg = Color(0xFFFFF8F0)
val ReaderLightText = Color(0xFF2C2C2C)
val ReaderDarkBg = Color(0xFF121212)
val ReaderDarkText = Color(0xFFE8E8E8)
val ReaderSepiaBg = Color(0xFFF4ECD8)
val ReaderSepiaText = Color(0xFF5C4B37)

// Error & Status
val ErrorLight = Color(0xFFBA1A1A)
val ErrorDark = Color(0xFFFFB4AB)
val SuccessLight = Color(0xFF2E7D32)
val SuccessDark = Color(0xFF66BB6A)
