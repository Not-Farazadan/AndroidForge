package com.premium.reader.data.repository

import com.premium.reader.data.local.dao.BookDao
import com.premium.reader.data.model.toDomain
import com.premium.reader.data.model.toEntity
import com.premium.reader.domain.model.*
import com.premium.reader.domain.repository.BookRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BookRepositoryImpl @Inject constructor(
    private val bookDao: BookDao
) : BookRepository {

    override fun getEbooks(): Flow<List<Book>> {
        return bookDao.getBooksByType("ebook").map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getAudiobooks(): Flow<List<Book>> {
        return bookDao.getBooksByType("audiobook").map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override fun getBookById(bookId: String): Flow<Book?> {
        return bookDao.getBookById(bookId).map { it?.toDomain() }
    }

    override suspend fun getBookByIdSync(bookId: String): Book? {
        return bookDao.getBookByIdSync(bookId)?.toDomain()
    }

    override fun getLastReadEbook(): Flow<Book?> {
        return bookDao.getLastReadBook("ebook").map { it?.toDomain() }
    }

    override fun getLastReadAudiobook(): Flow<Book?> {
        return bookDao.getLastReadBook("audiobook").map { it?.toDomain() }
    }

    override suspend fun insertBook(book: Book) {
        bookDao.insertBook(book.toEntity())
    }

    override suspend fun updateBook(book: Book) {
        bookDao.updateBook(book.toEntity())
    }

    override suspend fun updateProgress(bookId: String, page: Int, position: Long, progress: Float) {
        bookDao.updateProgress(bookId, page, position, progress, System.currentTimeMillis())
    }

    override suspend fun deleteBook(bookId: String) {
        bookDao.deleteBookById(bookId)
    }

    override suspend fun loadSampleContent() {
        // Sample ebooks
        val ebooks = listOf(
            Book(
                id = "ebook_1",
                title = "Pride and Prejudice",
                author = "Jane Austen",
                description = "A romantic novel of manners written by Jane Austen. The story follows the main character, Elizabeth Bennet, as she deals with issues of morality, upbringing, and marriage in the society of the landed gentry of early 19th-century England.",
                coverPath = "covers/pride_prejudice.jpg",
                filePath = "ebooks/pride_prejudice.epub",
                type = BookType.EBOOK,
                totalPages = 432
            ),
            Book(
                id = "ebook_2",
                title = "The Adventures of Sherlock Holmes",
                author = "Arthur Conan Doyle",
                description = "A collection of twelve short stories featuring Sherlock Holmes, first published in 1892. These are the first set of Holmes stories, including 'A Scandal in Bohemia' and 'The Red-Headed League'.",
                coverPath = "covers/sherlock.jpg",
                filePath = "ebooks/sherlock.epub",
                type = BookType.EBOOK,
                totalPages = 307
            ),
            Book(
                id = "ebook_3",
                title = "Alice's Adventures in Wonderland",
                author = "Lewis Carroll",
                description = "An 1865 novel that tells of a young girl named Alice, who falls through a rabbit hole into a fantasy world of anthropomorphic creatures. The tale is filled with allusions to Dodgson's friends and the lessons that British schoolchildren were expected to memorize.",
                coverPath = "covers/alice.jpg",
                filePath = "ebooks/alice.epub",
                type = BookType.EBOOK,
                totalPages = 224
            )
        )

        // Sample audiobooks
        val audiobooks = listOf(
            Book(
                id = "audio_1",
                title = "The Tell-Tale Heart",
                author = "Edgar Allan Poe",
                description = "A short story by Edgar Allan Poe first published in 1843. It is told by an unnamed narrator who endeavors to convince the reader of the narrator's sanity while simultaneously describing a murder the narrator committed.",
                coverPath = "covers/telltale.jpg",
                filePath = "audiobooks/telltale.mp3",
                type = BookType.AUDIOBOOK,
                totalDuration = 480000, // 8 minutes
                chapters = listOf(
                    Chapter("Chapter 1", startPosition = 0)
                )
            ),
            Book(
                id = "audio_2",
                title = "The Raven",
                author = "Edgar Allan Poe",
                description = "A narrative poem by Edgar Allan Poe, first published in January 1845. Noted for its musicality, stylized language, and supernatural atmosphere, it tells of a talking raven's mysterious visit to a distraught lover.",
                coverPath = "covers/raven.jpg",
                filePath = "audiobooks/raven.mp3",
                type = BookType.AUDIOBOOK,
                totalDuration = 360000, // 6 minutes
                chapters = listOf(
                    Chapter("The Poem", startPosition = 0)
                )
            ),
            Book(
                id = "audio_3",
                title = "A Christmas Carol",
                author = "Charles Dickens",
                description = "A novella by Charles Dickens, first published in 1843. It tells the story of Ebenezer Scrooge, an elderly miser who is visited by the ghost of his former business partner Jacob Marley and the spirits of Christmas Past, Present and Yet to Come.",
                coverPath = "covers/christmas_carol.jpg",
                filePath = "audiobooks/christmas_carol.mp3",
                type = BookType.AUDIOBOOK,
                totalDuration = 1800000, // 30 minutes
                chapters = listOf(
                    Chapter("Stave I: Marley's Ghost", startPosition = 0),
                    Chapter("Stave II: The First of the Three Spirits", startPosition = 420000),
                    Chapter("Stave III: The Second of the Three Spirits", startPosition = 900000),
                    Chapter("Stave IV: The Last of the Spirits", startPosition = 1320000),
                    Chapter("Stave V: The End of It", startPosition = 1620000)
                )
            )
        )

        bookDao.insertBooks((ebooks + audiobooks).map { it.toEntity() })
    }
}
