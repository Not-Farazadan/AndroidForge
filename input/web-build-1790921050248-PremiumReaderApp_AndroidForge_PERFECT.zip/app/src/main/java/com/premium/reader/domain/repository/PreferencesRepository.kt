package com.premium.reader.domain.repository

import com.premium.reader.domain.model.AudioSettings
import com.premium.reader.domain.model.ReaderSettings
import kotlinx.coroutines.flow.Flow

interface PreferencesRepository {
    fun getReaderSettings(): Flow<ReaderSettings>
    suspend fun updateReaderSettings(settings: ReaderSettings)
    fun getAudioSettings(): Flow<AudioSettings>
    suspend fun updateAudioSettings(settings: AudioSettings)
}
