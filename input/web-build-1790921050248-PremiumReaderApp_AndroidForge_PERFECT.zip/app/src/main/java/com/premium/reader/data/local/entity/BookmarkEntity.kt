package com.premium.reader.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val bookId: String,
    val page: Int = 0, // For ebooks
    val position: Long = 0, // For audiobooks in milliseconds
    val chapterTitle: String = "",
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
