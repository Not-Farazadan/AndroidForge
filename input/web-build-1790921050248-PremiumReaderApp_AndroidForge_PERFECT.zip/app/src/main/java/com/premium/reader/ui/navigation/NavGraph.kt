package com.premium.reader.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.premium.reader.ui.home.HomeScreen
import com.premium.reader.ui.player.AudioPlayerScreen
import com.premium.reader.ui.reader.EbookReaderScreen
import com.premium.reader.ui.settings.SettingsScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object EbookReader : Screen("reader/{bookId}") {
        fun createRoute(bookId: String) = "reader/$bookId"
    }
    object AudioPlayer : Screen("player/{bookId}") {
        fun createRoute(bookId: String) = "player/$bookId"
    }
    object Settings : Screen("settings")
}

@Composable
fun ReaderNavGraph(
    navController: NavHostController
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onBookClick = { book ->
                    val route = if (book.type == com.premium.reader.domain.model.BookType.EBOOK) {
                        Screen.EbookReader.createRoute(book.id)
                    } else {
                        Screen.AudioPlayer.createRoute(book.id)
                    }
                    navController.navigate(route)
                },
                onSettingsClick = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(
            route = Screen.EbookReader.route,
            arguments = listOf(
                navArgument("bookId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getString("bookId") ?: return@composable
            EbookReaderScreen(
                bookId = bookId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.AudioPlayer.route,
            arguments = listOf(
                navArgument("bookId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getString("bookId") ?: return@composable
            AudioPlayerScreen(
                bookId = bookId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
