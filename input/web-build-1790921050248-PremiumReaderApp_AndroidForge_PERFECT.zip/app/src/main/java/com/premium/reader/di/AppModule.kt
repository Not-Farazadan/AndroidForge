package com.premium.reader.di

import android.content.Context
import androidx.room.Room
import com.premium.reader.data.local.ReaderDatabase
import com.premium.reader.data.local.dao.BookDao
import com.premium.reader.data.local.dao.BookmarkDao
import com.premium.reader.data.repository.BookRepositoryImpl
import com.premium.reader.data.repository.BookmarkRepositoryImpl
import com.premium.reader.data.repository.PreferencesRepositoryImpl
import com.premium.reader.domain.repository.BookRepository
import com.premium.reader.domain.repository.BookmarkRepository
import com.premium.reader.domain.repository.PreferencesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideReaderDatabase(@ApplicationContext context: Context): ReaderDatabase {
        return Room.databaseBuilder(
            context,
            ReaderDatabase::class.java,
            "reader_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideBookDao(database: ReaderDatabase): BookDao {
        return database.bookDao()
    }

    @Provides
    @Singleton
    fun provideBookmarkDao(database: ReaderDatabase): BookmarkDao {
        return database.bookmarkDao()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideBookRepository(bookDao: BookDao): BookRepository {
        return BookRepositoryImpl(bookDao)
    }

    @Provides
    @Singleton
    fun provideBookmarkRepository(bookmarkDao: BookmarkDao): BookmarkRepository {
        return BookmarkRepositoryImpl(bookmarkDao)
    }

    @Provides
    @Singleton
    fun providePreferencesRepository(@ApplicationContext context: Context): PreferencesRepository {
        return PreferencesRepositoryImpl(context)
    }
}
