package com.premium.reader.ui.reader

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.premium.reader.R
import com.premium.reader.domain.model.*
import com.premium.reader.ui.common.LoadingIndicator
import com.premium.reader.ui.theme.ReaderDarkBg
import com.premium.reader.ui.theme.ReaderDarkText
import com.premium.reader.ui.theme.ReaderLightBg
import com.premium.reader.ui.theme.ReaderLightText
import com.premium.reader.ui.theme.ReaderSepiaBg
import com.premium.reader.ui.theme.ReaderSepiaText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EbookReaderScreen(
    bookId: String,
    onBack: () -> Unit,
    viewModel: EbookReaderViewModel = hiltViewModel()
) {
    LaunchedEffect(bookId) {
        viewModel.loadBook(bookId)
    }

    val uiState by viewModel.uiState.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showControls by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val backgroundColor = when (settings.theme) {
        ReaderTheme.LIGHT -> ReaderLightBg
        ReaderTheme.DARK -> ReaderDarkBg
        ReaderTheme.SEPIA -> ReaderSepiaBg
    }

    val textColor = when (settings.theme) {
        ReaderTheme.LIGHT -> ReaderLightText
        ReaderTheme.DARK -> ReaderDarkText
        ReaderTheme.SEPIA -> ReaderSepiaText
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        val third = size.width / 3
                        when {
                            offset.x < third -> viewModel.previousPage()
                            offset.x > third * 2 -> viewModel.nextPage()
                            else -> showControls = !showControls
                        }
                    }
                )
            }
    ) {
        when {
            uiState.isLoading -> {
                LoadingIndicator()
            }
            uiState.error != null -> {
                ErrorContent(
                    error = uiState.error!!,
                    onBack = onBack
                )
            }
            uiState.book != null && uiState.currentPageContent != null -> {
                ReaderContent(
                    content = uiState.currentPageContent!!,
                    settings = settings,
                    textColor = textColor
                )

                // Top and Bottom Controls
                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn() + slideInVertically { -it },
                    exit = fadeOut() + slideOutVertically { -it }
                ) {
                    TopBar(
                        title = uiState.book!!.title,
                        onBack = onBack,
                        onSettingsClick = { showSettings = true },
                        backgroundColor = backgroundColor
                    )
                }

                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn() + slideInVertically { it },
                    exit = fadeOut() + slideOutVertically { it }
                ) {
                    BottomBar(
                        currentPage = uiState.currentPage,
                        totalPages = uiState.book!!.totalPages,
                        onPageChange = { viewModel.goToPage(it) },
                        onBookmarkClick = { viewModel.addBookmark() },
                        backgroundColor = backgroundColor,
                        textColor = textColor
                    )
                }
            }
        }
    }

    if (showSettings) {
        ReaderSettingsSheet(
            settings = settings,
            onDismiss = { showSettings = false },
            onFontFamilyChange = { viewModel.updateFontFamily(it) },
            onFontSizeChange = { viewModel.updateFontSize(it) },
            onLineSpacingChange = { viewModel.updateLineSpacing(it) },
            onTextAlignmentChange = { viewModel.updateTextAlignment(it) },
            onThemeChange = { viewModel.updateTheme(it) }
        )
    }
}

@Composable
private fun ReaderContent(
    content: String,
    settings: ReaderSettings,
    textColor: Color
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(scrollState)
            .padding(vertical = 48.dp)
    ) {
        Text(
            text = content,
            fontSize = settings.fontSize.sp,
            lineHeight = (settings.fontSize * settings.lineSpacing.multiplier).sp,
            color = textColor,
            textAlign = when (settings.textAlignment) {
                TextAlignment.LEFT -> TextAlign.Start
                TextAlignment.CENTER -> TextAlign.Center
                TextAlignment.JUSTIFY -> TextAlign.Justify
            },
            fontFamily = when {
                settings.fontFamily.fontName == "serif" -> FontFamily.Serif
                settings.fontFamily.fontName == "sans-serif" -> FontFamily.SansSerif
                else -> FontFamily.Default
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BoxScope.TopBar(
    title: String,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    backgroundColor: Color
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter),
        color = backgroundColor.copy(alpha = 0.95f),
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back"
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onSettingsClick) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings"
                )
            }
        }
    }
}

@Composable
private fun BoxScope.BottomBar(
    currentPage: Int,
    totalPages: Int,
    onPageChange: (Int) -> Unit,
    onBookmarkClick: () -> Unit,
    backgroundColor: Color,
    textColor: Color
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter),
        color = backgroundColor.copy(alpha = 0.95f),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Page $currentPage of $totalPages",
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor
                )
                IconButton(onClick = onBookmarkClick) {
                    Icon(
                        imageVector = Icons.Default.BookmarkAdd,
                        contentDescription = "Add Bookmark",
                        tint = textColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Slider(
                value = currentPage.toFloat(),
                onValueChange = { onPageChange(it.toInt()) },
                valueRange = 1f..totalPages.toFloat(),
                steps = totalPages - 2,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "${((currentPage.toFloat() / totalPages) * 100).toInt()}% complete",
                style = MaterialTheme.typography.bodySmall,
                color = textColor,
                modifier = Modifier.align(Alignment.End)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderSettingsSheet(
    settings: ReaderSettings,
    onDismiss: () -> Unit,
    onFontFamilyChange: (FontFamily) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onLineSpacingChange: (LineSpacing) -> Unit,
    onTextAlignmentChange: (TextAlignment) -> Unit,
    onThemeChange: (ReaderTheme) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = stringResource(R.string.reading_settings),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Font Family
            Text(
                text = stringResource(R.string.font_family),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                com.premium.reader.domain.model.FontFamily.entries.take(4).forEach { font ->
                    OutlinedButton(
                        onClick = { onFontFamilyChange(font) },
                        modifier = Modifier.weight(1f),
                        colors = if (settings.fontFamily == font) {
                            ButtonDefaults.outlinedButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        } else {
                            ButtonDefaults.outlinedButtonColors()
                        }
                    ) {
                        Text(
                            text = font.displayName.take(8),
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Font Size
            Text(
                text = stringResource(R.string.font_size),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (settings.fontSize > 12) {
                            onFontSizeChange(settings.fontSize - 2)
                        }
                    }
                ) {
                    Icon(Icons.Default.Remove, "Decrease")
                }
                Text(
                    text = "${settings.fontSize}sp",
                    style = MaterialTheme.typography.bodyLarge
                )
                IconButton(
                    onClick = {
                        if (settings.fontSize < 28) {
                            onFontSizeChange(settings.fontSize + 2)
                        }
                    }
                ) {
                    Icon(Icons.Default.Add, "Increase")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Theme
            Text(
                text = stringResource(R.string.theme),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReaderTheme.entries.forEach { theme ->
                    OutlinedButton(
                        onClick = { onThemeChange(theme) },
                        modifier = Modifier.weight(1f),
                        colors = if (settings.theme == theme) {
                            ButtonDefaults.outlinedButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        } else {
                            ButtonDefaults.outlinedButtonColors()
                        }
                    ) {
                        Text(
                            text = theme.displayName,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ErrorContent(
    error: String,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = "Error",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = error,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onBack) {
                Text("Go Back")
            }
        }
    }
}
