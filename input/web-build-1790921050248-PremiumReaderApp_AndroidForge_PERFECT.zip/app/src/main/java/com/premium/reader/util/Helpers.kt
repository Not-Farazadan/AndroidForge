package com.premium.reader.util

import android.content.Context
import java.io.File
import java.io.FileOutputStream

object AssetHelper {
    fun copyAssetToFile(context: Context, assetPath: String, targetFile: File): Boolean {
        return try {
            context.assets.open(assetPath).use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun getAssetPath(context: Context, assetPath: String): String {
        val file = File(context.cacheDir, assetPath)
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            copyAssetToFile(context, assetPath, file)
        }
        return file.absolutePath
    }
}

fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000).toInt()
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60

    return when {
        hours > 0 -> String.format("%d:%02d:%02d", hours, minutes, seconds)
        else -> String.format("%d:%02d", minutes, seconds)
    }
}

fun formatProgress(progress: Float): String {
    return "${(progress * 100).toInt()}%"
}
