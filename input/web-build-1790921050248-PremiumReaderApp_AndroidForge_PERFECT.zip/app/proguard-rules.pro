# Add project specific ProGuard rules here.

# Keep Room entities
-keep class com.premium.reader.data.local.entity.** { *; }

# Keep data models
-keep class com.premium.reader.data.model.** { *; }

# EPUB library
-keep class nl.siegmann.epublib.** { *; }
-dontwarn nl.siegmann.epublib.**

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Compose
-keep class androidx.compose.** { *; }
