# Premium Reader — AndroidForge build package

This ZIP is the Android source project itself. The project root is intentionally at the ZIP root so AndroidForge can detect `settings.gradle.kts`, `build.gradle.kts`, `gradlew`, and the `app/` module immediately.

Identity checks:
- App label: Premium Reader
- Application ID / namespace: com.premium.reader
- Launcher activity: com.premium.reader.MainActivity
- Root project: PremiumReaderApp
- Module: app
- Build system: native Gradle + Kotlin + Jetpack Compose

IMPORTANT: In AndroidForge, use the Diagnostics workflow first if available. It should classify this as a Gradle/Kotlin Android project and discover the `app` module. Only start the full APK build after that check looks correct.

Do not rename this ZIP to a web-build or Quick Launch project, and do not upload an APK as the input. Upload this ZIP as the Android source ZIP.
