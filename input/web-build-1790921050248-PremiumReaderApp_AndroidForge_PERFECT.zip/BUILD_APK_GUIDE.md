# Building APK Without Android Studio

## Prerequisites

Before building, you need:

1. **Java Development Kit (JDK) 17**
   - Download from: https://adoptium.net/
   - Verify installation: `java -version`

2. **Android SDK Command Line Tools**
   - Download from: https://developer.android.com/studio#command-tools
   - Or install via SDK Manager if you have it

## Method 1: Using Gradle Wrapper (Recommended)

The project includes a Gradle wrapper, so you don't need to install Gradle separately.

### Windows (PowerShell/Command Prompt):

```powershell
# Navigate to project directory
cd PremiumReaderApp

# Build debug APK (no signing required)
.\gradlew assembleDebug

# Build release APK (requires signing)
.\gradlew assembleRelease
```

### Linux/Mac (Terminal):

```bash
# Navigate to project directory
cd PremiumReaderApp

# Make gradlew executable (first time only)
chmod +x gradlew

# Build debug APK (no signing required)
./gradlew assembleDebug

# Build release APK (requires signing)
./gradlew assembleRelease
```

## Output Location

After successful build, the APK will be located at:

**Debug APK:**
```
app/build/outputs/apk/debug/app-debug.apk
```

**Release APK:**
```
app/build/outputs/apk/release/app-release-unsigned.apk
```

## Method 2: Complete Step-by-Step Setup

If you don't have Android SDK installed:

### Step 1: Install JDK 17

**Windows:**
1. Download JDK 17 from https://adoptium.net/
2. Install and note the installation path
3. Set JAVA_HOME environment variable:
   ```powershell
   setx JAVA_HOME "C:\Program Files\Eclipse Adoptium\jdk-17.0.x"
   ```

**Linux:**
```bash
sudo apt update
sudo apt install openjdk-17-jdk
```

**Mac:**
```bash
brew install openjdk@17
```

### Step 2: Install Android SDK

**Option A: Using SDK Manager (if you have it)**
```bash
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

**Option B: Manual Installation**
1. Download Android Command Line Tools from:
   https://developer.android.com/studio#command-tools
2. Extract to a folder (e.g., `C:\Android\sdk` or `~/Android/sdk`)
3. Set ANDROID_HOME environment variable:
   
   **Windows:**
   ```powershell
   setx ANDROID_HOME "C:\Android\sdk"
   ```
   
   **Linux/Mac:**
   ```bash
   export ANDROID_HOME=~/Android/sdk
   echo 'export ANDROID_HOME=~/Android/sdk' >> ~/.bashrc
   ```

### Step 3: Accept Android SDK Licenses

```bash
# Windows
%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager --licenses

# Linux/Mac
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
```

### Step 4: Build the APK

```bash
cd PremiumReaderApp

# Windows
.\gradlew assembleDebug

# Linux/Mac
./gradlew assembleDebug
```

## Troubleshooting Common Issues

### Issue 1: "JAVA_HOME not set"

**Solution:**
```powershell
# Windows
setx JAVA_HOME "C:\Program Files\Eclipse Adoptium\jdk-17.0.x"

# Linux/Mac
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
```

### Issue 2: "Android SDK not found"

**Solution:**
Create `local.properties` file in project root:
```properties
sdk.dir=C:\\Android\\sdk
```
(Use forward slashes on Linux/Mac: `sdk.dir=/home/user/Android/sdk`)

### Issue 3: "Permission denied: ./gradlew"

**Solution (Linux/Mac):**
```bash
chmod +x gradlew
```

### Issue 4: "SDK location not found"

**Solution:**
Either:
1. Set ANDROID_HOME environment variable, OR
2. Create `local.properties` with sdk.dir

### Issue 5: Build fails with "SDK Platform not found"

**Solution:**
Install the required SDK platform:
```bash
sdkmanager "platforms;android-34"
```

## Signing the APK for Release

For a release APK that can be installed on devices, you need to sign it.

### Step 1: Create a Keystore

```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

Answer the prompts (name, organization, password, etc.)

### Step 2: Configure Signing in build.gradle.kts

Add to `app/build.gradle.kts`:

```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file("../my-release-key.jks")
            storePassword = "your-keystore-password"
            keyAlias = "my-key-alias"
            keyPassword = "your-key-password"
        }
    }
    
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
```

### Step 3: Build Signed APK

```bash
.\gradlew assembleRelease
```

The signed APK will be at:
```
app/build/outputs/apk/release/app-release.apk
```

## Quick Build Script

Save this as `build-apk.bat` (Windows) or `build-apk.sh` (Linux/Mac):

**Windows (build-apk.bat):**
```batch
@echo off
echo Building Premium Reader APK...
echo.

if not exist "gradlew.bat" (
    echo ERROR: gradlew.bat not found. Are you in the project directory?
    pause
    exit /b 1
)

echo Cleaning previous builds...
call gradlew.bat clean

echo Building debug APK...
call gradlew.bat assembleDebug

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ✓ Build successful!
    echo.
    echo APK location: app\build\outputs\apk\debug\app-debug.apk
    echo.
    start explorer app\build\outputs\apk\debug
) else (
    echo.
    echo ✗ Build failed. Check the error messages above.
)

pause
```

**Linux/Mac (build-apk.sh):**
```bash
#!/bin/bash

echo "Building Premium Reader APK..."
echo ""

if [ ! -f "gradlew" ]; then
    echo "ERROR: gradlew not found. Are you in the project directory?"
    exit 1
fi

chmod +x gradlew

echo "Cleaning previous builds..."
./gradlew clean

echo "Building debug APK..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "✓ Build successful!"
    echo ""
    echo "APK location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    open app/build/outputs/apk/debug 2>/dev/null || xdg-open app/build/outputs/apk/debug 2>/dev/null
else
    echo ""
    echo "✗ Build failed. Check the error messages above."
fi
```

Make it executable (Linux/Mac):
```bash
chmod +x build-apk.sh
./build-apk.sh
```

## Installing the APK on Device

Once built, you can install it:

### Method 1: Via ADB (Android Debug Bridge)

```bash
# Windows
adb install app\build\outputs\apk\debug\app-debug.apk

# Linux/Mac
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Method 2: Manual Transfer

1. Copy the APK to your phone (USB, email, cloud)
2. On your phone, enable "Install from Unknown Sources"
3. Open the APK file to install

## Summary

**Simplest way to build APK:**

```bash
cd PremiumReaderApp
.\gradlew assembleDebug    # Windows
./gradlew assembleDebug    # Linux/Mac
```

**APK will be at:**
```
app/build/outputs/apk/debug/app-debug.apk
```

That's it! No Android Studio needed. Just JDK 17 and the Android SDK.
