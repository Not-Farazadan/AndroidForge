## Testing Checklist

### Home Screen
- [ ] App launches successfully without crashes
- [ ] Tab switching between Ebooks and Audiobooks is smooth
- [ ] Book covers load correctly (or show placeholders)
- [ ] Grid layout displays properly in portrait and landscape
- [ ] Continue Reading/Listening card appears for in-progress books
- [ ] Clicking on a book navigates to appropriate screen
- [ ] Settings button opens settings screen
- [ ] Empty state shows when no books present
- [ ] Pull-to-refresh animation works smoothly

### Ebook Reader
- [ ] Reader opens with correct book
- [ ] Text is readable with default settings
- [ ] Tap zones work (left = previous, right = next, center = controls)
- [ ] Top bar shows/hides on center tap
- [ ] Bottom bar shows/hides on center tap
- [ ] Page navigation slider works correctly
- [ ] Progress percentage updates correctly
- [ ] Font family changes apply immediately
- [ ] Font size changes apply immediately
- [ ] Theme switching works without flicker (Light/Dark/Sepia)
- [ ] Line spacing changes are visible
- [ ] Text alignment changes work
- [ ] Back button returns to home
- [ ] Settings sheet opens and closes smoothly
- [ ] Bookmarks can be added
- [ ] Reading progress persists on back navigation

### Audiobook Player
- [ ] Player opens with correct audiobook
- [ ] Cover art displays prominently
- [ ] Play/Pause button toggles correctly
- [ ] Play/Pause icon morphs smoothly
- [ ] Progress slider updates during playback
- [ ] Time indicators update correctly
- [ ] Skip forward (30s) works
- [ ] Skip backward (30s) works
- [ ] Next chapter button works
- [ ] Previous chapter button works
- [ ] Playback speed dialog shows all options (0.5x - 2x)
- [ ] Playback speed changes apply immediately
- [ ] Sleep timer dialog shows all options
- [ ] Sleep timer stops playback after duration
- [ ] Chapters dialog shows all chapters
- [ ] Chapter selection jumps to correct position
- [ ] Scrubbing slider works smoothly
- [ ] Back button returns to home
- [ ] Bookmarks can be added
- [ ] Playback progress persists on back navigation

### Settings Screen
- [ ] Settings screen opens correctly
- [ ] TTS voice dialog shows both voices
- [ ] Voice selection updates setting
- [ ] Playback speed dialog works
- [ ] Speed selection updates setting
- [ ] Auto-play toggle works
- [ ] Font family dialog shows all fonts
- [ ] Font selection updates default
- [ ] Font size dialog shows all sizes
- [ ] Theme dialog shows all themes
- [ ] Theme selection updates default
- [ ] Version number displays correctly
- [ ] Back button returns to home

### Theme & Dark Mode
- [ ] Light theme looks correct
- [ ] Dark theme looks correct
- [ ] Sepia theme looks correct (reader only)
- [ ] System bars respect theme
- [ ] Status bar icons have correct color
- [ ] Navigation bar icons have correct color
- [ ] Theme persists across app restarts
- [ ] No flashing during theme switch
- [ ] All text is readable in all themes

### Animations
- [ ] All transitions are smooth (60fps)
- [ ] No janky animations
- [ ] Tab switching has smooth indicator animation
- [ ] Page transitions in reader are smooth
- [ ] Play/Pause button morphs smoothly
- [ ] Bottom sheets slide in smoothly
- [ ] Dialogs fade in/out smoothly
- [ ] Shared element transitions work (if implemented)

### Performance
- [ ] App launches within 2 seconds
- [ ] No ANRs (Application Not Responding)
- [ ] Smooth scrolling in grid view
- [ ] Smooth scrolling in reader
- [ ] No memory leaks (check with LeakCanary)
- [ ] Battery usage is reasonable during playback
- [ ] No excessive CPU usage
- [ ] Image loading doesn't block UI

### Edge Cases
- [ ] Rotation preserves state in all screens
- [ ] Process death restores state correctly
- [ ] Empty library shows proper message
- [ ] Missing cover images handled gracefully
- [ ] Network error handling (if applicable)
- [ ] Database errors handled gracefully
- [ ] Book at 100% progress handled correctly
- [ ] First/last page boundaries work
- [ ] First/last chapter boundaries work

### Accessibility
- [ ] All buttons have content descriptions
- [ ] TalkBack can navigate the app
- [ ] Touch targets are at least 48x48dp
- [ ] Text has sufficient contrast
- [ ] Focus order is logical

### Different Screen Sizes
- [ ] Works on small phone (5")
- [ ] Works on large phone (6.5"+)
- [ ] Works on tablet (10")
- [ ] Grid columns adjust appropriately
- [ ] Text is readable on all sizes
- [ ] Controls are accessible on all sizes

### State Persistence
- [ ] Reading progress saves correctly
- [ ] Listening progress saves correctly
- [ ] Settings persist across restarts
- [ ] Last read book remembered
- [ ] Bookmarks persist
- [ ] Theme preference persists

## Bug Report Template

**Device**: [Phone model]
**Android Version**: [e.g., Android 13]
**App Version**: 1.0.0

**Steps to Reproduce**:
1. 
2. 
3. 

**Expected Behavior**:

**Actual Behavior**:

**Screenshots/Video**:

**Logs** (if applicable):
