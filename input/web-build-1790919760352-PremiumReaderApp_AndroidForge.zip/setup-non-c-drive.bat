@echo off
echo.
echo ═══════════════════════════════════════════════════════════
echo   Configure Build to Avoid C Drive
echo ═══════════════════════════════════════════════════════════
echo.
echo This script will configure your build environment to use
echo a different drive (E:, D:, F:, etc.) instead of C drive.
echo.
echo Default setup uses C:\Users\YourName\.gradle (~1.5-2 GB)
echo.

REM Ask user for preferred drive
set /p DRIVE="Enter your preferred drive letter (e.g., E, D, F): "

REM Validate input
if "%DRIVE%"=="" (
    echo Error: No drive letter entered
    pause
    exit /b 1
)

REM Add colon if not present
echo %DRIVE% | findstr ":" >nul
if errorlevel 1 (
    set DRIVE=%DRIVE%:
)

echo.
echo Selected drive: %DRIVE%
echo.
echo This will create the following directories:
echo   %DRIVE%\Gradle     (Gradle cache, ~1.5-2 GB)
echo   %DRIVE%\Temp       (Build temp files)
echo   %DRIVE%\Android    (Optional Android SDK)
echo.

set /p CONFIRM="Proceed with setup? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo Setup cancelled.
    pause
    exit /b 0
)

echo.
echo ───────────────────────────────────────────────────────────
echo   Creating Directories...
echo ───────────────────────────────────────────────────────────
echo.

mkdir "%DRIVE%\Gradle" 2>nul
if exist "%DRIVE%\Gradle" (
    echo ✓ Created: %DRIVE%\Gradle
) else (
    echo ✗ Failed to create: %DRIVE%\Gradle
)

mkdir "%DRIVE%\Temp" 2>nul
if exist "%DRIVE%\Temp" (
    echo ✓ Created: %DRIVE%\Temp
) else (
    echo ✗ Failed to create: %DRIVE%\Temp
)

mkdir "%DRIVE%\Android" 2>nul
if exist "%DRIVE%\Android" (
    echo ✓ Created: %DRIVE%\Android
) else (
    echo ✗ Failed to create: %DRIVE%\Android
)

echo.
echo ───────────────────────────────────────────────────────────
echo   Setting Environment Variables...
echo ───────────────────────────────────────────────────────────
echo.

REM Set GRADLE_USER_HOME
setx GRADLE_USER_HOME "%DRIVE%\Gradle" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo ✓ GRADLE_USER_HOME = %DRIVE%\Gradle
) else (
    echo ✗ Failed to set GRADLE_USER_HOME
)

REM Set ANDROID_HOME (optional, for if SDK is needed)
setx ANDROID_HOME "%DRIVE%\Android\sdk" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo ✓ ANDROID_HOME = %DRIVE%\Android\sdk
) else (
    echo ✗ Failed to set ANDROID_HOME
)

REM Set ANDROID_SDK_ROOT
setx ANDROID_SDK_ROOT "%DRIVE%\Android\sdk" >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo ✓ ANDROID_SDK_ROOT = %DRIVE%\Android\sdk
) else (
    echo ✗ Failed to set ANDROID_SDK_ROOT
)

echo.
echo ───────────────────────────────────────────────────────────
echo   Creating Configuration Files...
echo ───────────────────────────────────────────────────────────
echo.

REM Create local.properties
set LOCAL_PROPS=local.properties
(
echo # Android SDK location on %DRIVE% drive
echo sdk.dir=%DRIVE:\=\\%\\Android\\sdk
) > "%LOCAL_PROPS%"

if exist "%LOCAL_PROPS%" (
    echo ✓ Created: local.properties
) else (
    echo ✗ Failed to create local.properties
)

REM Update gradle.properties
set GRADLE_PROPS=gradle.properties

REM Check if file exists, backup if it does
if exist "%GRADLE_PROPS%" (
    copy "%GRADLE_PROPS%" "%GRADLE_PROPS%.backup" >nul 2>&1
    echo ✓ Backed up existing gradle.properties
)

REM Append or create gradle.properties
(
echo.
echo # Custom configuration to avoid C drive
echo org.gradle.user.home=%DRIVE:\=\\%\\Gradle
echo org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8 -Djava.io.tmpdir=%DRIVE:\=\\%\\Temp
) >> "%GRADLE_PROPS%"

if exist "%GRADLE_PROPS%" (
    echo ✓ Updated: gradle.properties
) else (
    echo ✗ Failed to update gradle.properties
)

echo.
echo ═══════════════════════════════════════════════════════════
echo   ✓ Configuration Complete!
echo ═══════════════════════════════════════════════════════════
echo.
echo What was configured:
echo   • Gradle cache:    %DRIVE%\Gradle
echo   • Temp files:      %DRIVE%\Temp
echo   • Android SDK:     %DRIVE%\Android\sdk
echo.
echo Space requirements:
echo   • Gradle cache:    ~1.5-2 GB (on first build)
echo   • Android SDK:     ~3-5 GB (optional, if needed)
echo   • Build output:    ~30 MB (stays in project folder)
echo.
echo ⚠️  IMPORTANT: You MUST restart your computer (or log out/in)
echo    for environment variables to take effect.
echo.
echo After restart:
echo   1. Run build-apk.bat to build your APK
echo   2. Everything will be stored on %DRIVE% drive
echo   3. Your C drive will NOT be touched
echo.
echo Verify configuration after restart:
echo   echo %%GRADLE_USER_HOME%%
echo   (Should show: %DRIVE%\Gradle)
echo.
pause
