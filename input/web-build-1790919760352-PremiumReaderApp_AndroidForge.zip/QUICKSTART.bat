@echo off
echo 🚀 Premium Reader App - Quick Start Guide
echo ==========================================
echo.

echo 📋 Prerequisites:
echo   ✓ Android Studio Hedgehog (2023.1.1) or newer
echo   ✓ JDK 17
echo   ✓ Android SDK API 34
echo   ✓ Gradle 8.7
echo.

echo 🔨 Build Commands:
echo   Debug build:   gradlew assembleDebug
echo   Release build: gradlew assembleRelease
echo   Install:       gradlew installDebug
echo   Clean:         gradlew clean
echo.

echo 🧪 Testing Commands:
echo   Unit tests:        gradlew test
echo   Instrumented:      gradlew connectedAndroidTest
echo   Lint check:        gradlew lint
echo.

echo 📱 Running the App:
echo   1. Open project in Android Studio
echo   2. Sync Gradle (File → Sync Project with Gradle Files)
echo   3. Select device/emulator (API 26+)
echo   4. Click Run button (▶️)
echo.

echo 📚 Project Structure:
echo   34 Kotlin files
echo   Clean Architecture (Data/Domain/UI layers)
echo   Jetpack Compose UI
echo   Hilt DI, Room DB, Navigation Compose
echo.

echo ✨ Features:
echo   ✓ Ebook reader with customizable fonts, themes, sizes
echo   ✓ Audiobook player with speed control, chapters, sleep timer
echo   ✓ Home screen with tabs and continue reading cards
echo   ✓ Settings for personalization
echo   ✓ Smooth 60fps animations throughout
echo.

echo 📖 Documentation:
echo   README.md         - Overview and setup
echo   ARCHITECTURE.md   - Architecture decisions and tech debt
echo   TESTING.md        - Testing checklist and bug template
echo   PROJECT_SUMMARY.md - Complete project documentation
echo.

echo 🎯 Next Steps:
echo   1. Sync project in Android Studio
echo   2. Build and run on device/emulator
echo   3. Explore the UI and features
echo   4. Check ARCHITECTURE.md for implementation details
echo   5. Add actual EPUB files and cover images (see docs)
echo.

echo ✅ Ready to build!
echo.
pause
