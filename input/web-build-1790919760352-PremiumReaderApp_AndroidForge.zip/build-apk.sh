#!/bin/bash

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Premium Reader - APK Builder (No Android Studio)"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Check if we're in the right directory
if [ ! -f "gradlew" ]; then
    echo "✗ ERROR: gradlew not found!"
    echo ""
    echo "Make sure you're running this script from the PremiumReaderApp directory."
    echo ""
    exit 1
fi

echo "✓ Project directory verified"
echo ""

# Make gradlew executable
chmod +x gradlew
echo "✓ gradlew permissions set"
echo ""

# Check Java installation
if ! command -v java &> /dev/null; then
    echo "✗ ERROR: Java not found!"
    echo ""
    echo "Please install JDK 17:"
    echo "  Ubuntu/Debian: sudo apt install openjdk-17-jdk"
    echo "  Mac: brew install openjdk@17"
    echo "  Or download from: https://adoptium.net/"
    echo ""
    exit 1
fi

echo "✓ Java installation found"
java -version 2>&1 | head -n 1
echo ""

# Check for local.properties or ANDROID_HOME
SDK_FOUND=0

if [ -f "local.properties" ]; then
    echo "✓ local.properties found"
    SDK_FOUND=1
elif [ ! -z "$ANDROID_HOME" ]; then
    echo "✓ ANDROID_HOME environment variable found"
    echo "  Location: $ANDROID_HOME"
    SDK_FOUND=1
else
    echo "⚠ Warning: Android SDK not configured"
    echo ""
    echo "You need to either:"
    echo "  1. Set ANDROID_HOME environment variable, OR"
    echo "  2. Create local.properties file with: sdk.dir=/path/to/Android/sdk"
    echo ""
    read -p "Do you want to continue anyway? The build might fail. (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Build cancelled."
        exit 1
    fi
fi

echo ""
echo "───────────────────────────────────────────────────────────"
echo "  Starting Build Process"
echo "───────────────────────────────────────────────────────────"
echo ""

# Clean previous builds
echo "[1/3] Cleaning previous builds..."
./gradlew clean --quiet
if [ $? -ne 0 ]; then
    echo "✗ Clean failed"
    exit 1
fi
echo "✓ Clean completed"
echo ""

# Build debug APK
echo "[2/3] Building debug APK (this may take a few minutes)..."
echo "      Please wait..."
echo ""
./gradlew assembleDebug

if [ $? -ne 0 ]; then
    echo ""
    echo "✗ Build FAILED!"
    echo ""
    echo "Common issues:"
    echo "  • Android SDK not found - set ANDROID_HOME or create local.properties"
    echo "  • Java version mismatch - ensure JDK 17 is installed"
    echo "  • Network issues - Gradle needs to download dependencies"
    echo ""
    echo "Check the error messages above for details."
    echo ""
    exit 1
fi

echo ""
echo "[3/3] Verifying output..."

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
    echo "✓ APK built successfully!"
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  ✓ BUILD COMPLETE!"
    echo "═══════════════════════════════════════════════════════════"
    echo ""
    echo "📦 APK Location:"
    echo "   $APK_PATH"
    echo ""

    # Get file size
    SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo "📊 APK Size: $SIZE"
    echo ""

    echo "📱 To install on your device:"
    echo "   Method 1: adb install $APK_PATH"
    echo "   Method 2: Copy APK to phone and install manually"
    echo ""

    # Open folder (platform-specific)
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open app/build/outputs/apk/debug
    elif command -v xdg-open &> /dev/null; then
        xdg-open app/build/outputs/apk/debug
    fi
else
    echo "✗ APK not found at expected location!"
    echo "   Expected: $APK_PATH"
fi

echo ""
