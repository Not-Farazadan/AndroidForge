# PremiumReaderApp — AndroidForge

Upload this ZIP to AndroidForge. It is a native Kotlin/Jetpack Compose Gradle project.

The Android project is at the ZIP root (not nested), Gradle wrapper is included, and machine-specific local.properties/generated Gradle caches/build outputs were removed.

Recommended AndroidForge settings:
- zip source: input-directory or upload through its web UI
- build variant: auto (or debug first)
- enable NDK: off unless the build log says it is needed
