# Premium Reader - APK Builder (PowerShell)
# This handles special characters and will NOT close automatically

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  Premium Reader - APK Builder" -ForegroundColor Cyan
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

# Check if we're in the right directory
if (-not (Test-Path "gradlew.bat")) {
    Write-Host "ERROR: gradlew.bat not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Make sure you're running this script from the PremiumReaderApp directory." -ForegroundColor Yellow
    Write-Host "Current directory: $(Get-Location)" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "[OK] Project directory verified" -ForegroundColor Green
Write-Host "Directory: $(Get-Location)"
Write-Host ""

# Check Java
try {
    $null = java -version 2>&1
    Write-Host "[OK] Java installation found" -ForegroundColor Green
    java -version 2>&1 | Select-String "version" | ForEach-Object { Write-Host $_ }
} catch {
    Write-Host "ERROR: Java not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install JDK 17 from: https://adoptium.net/" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host ""

Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  Starting Build (This will take 5-10 minutes on first run)" -ForegroundColor Cyan
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "What's happening:" -ForegroundColor Yellow
Write-Host "  1. Downloading Gradle (~100 MB)"
Write-Host "  2. Downloading Android dependencies (~1-2 GB)"
Write-Host "  3. Compiling your app"
Write-Host "  4. Creating APK"
Write-Host ""
Write-Host "Please be patient... DO NOT CLOSE THIS WINDOW!" -ForegroundColor Yellow
Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

# Run the build
& .\gradlew.bat assembleDebug

$buildResult = $LASTEXITCODE

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  Build Process Finished" -ForegroundColor Cyan
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

if ($buildResult -eq 0) {
    $apkPath = "app\build\outputs\apk\debug\app-debug.apk"

    if (Test-Path $apkPath) {
        Write-Host ""
        Write-Host "===================================================================" -ForegroundColor Green
        Write-Host "[SUCCESS] APK built successfully!" -ForegroundColor Green
        Write-Host "===================================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "APK Location: $(Resolve-Path $apkPath)" -ForegroundColor Cyan
        Write-Host ""

        $size = (Get-Item $apkPath).Length
        $sizeMB = [math]::Round($size / 1MB, 2)
        Write-Host "APK Size: $sizeMB MB" -ForegroundColor Cyan
        Write-Host ""

        Write-Host "Opening APK folder..." -ForegroundColor Yellow
        Start-Process explorer "app\build\outputs\apk\debug"
        Write-Host ""
        Write-Host "===================================================================" -ForegroundColor Green
        Write-Host "You can now install this APK on your Android device!" -ForegroundColor Green
        Write-Host "===================================================================" -ForegroundColor Green
    } else {
        Write-Host "[WARNING] Build reported success but APK not found at expected location." -ForegroundColor Yellow
        Write-Host "Expected: $apkPath" -ForegroundColor Yellow
    }
} else {
    Write-Host ""
    Write-Host "===================================================================" -ForegroundColor Red
    Write-Host "[ERROR] Build FAILED with error code: $buildResult" -ForegroundColor Red
    Write-Host "===================================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Common issues and solutions:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "1. INTERNET CONNECTION:" -ForegroundColor Cyan
    Write-Host "   - Make sure you have stable internet"
    Write-Host "   - First build downloads ~2 GB of dependencies"
    Write-Host ""
    Write-Host "2. DISK SPACE:" -ForegroundColor Cyan
    Write-Host "   - Need at least 2-3 GB free space"
    Write-Host "   - Check your E: drive"
    Write-Host ""
    Write-Host "3. FIREWALL/ANTIVIRUS:" -ForegroundColor Cyan
    Write-Host "   - May be blocking Gradle downloads"
    Write-Host "   - Try temporarily disabling"
    Write-Host ""
    Write-Host "4. MEMORY:" -ForegroundColor Cyan
    Write-Host "   - If you see OutOfMemoryError, close other programs"
    Write-Host ""
    Write-Host "Check the error messages above for specific details." -ForegroundColor Yellow
    Write-Host ""
}

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "*** PRESS ENTER TO EXIT ***" -ForegroundColor Yellow
Read-Host
