@echo off
REM Simple diagnostic script to check your setup

echo.
echo ===================================================================
echo   Premium Reader - Build Environment Diagnostic
echo ===================================================================
echo.

echo Checking Java installation...
echo -------------------------------------------------------------------
java -version 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [FAIL] Java not found or not in PATH
) else (
    echo [OK] Java is installed
)
echo.

echo Checking project structure...
echo -------------------------------------------------------------------
if exist "gradlew.bat" (
    echo [OK] gradlew.bat found
) else (
    echo [FAIL] gradlew.bat not found
)

if exist "gradle\wrapper\gradle-wrapper.jar" (
    echo [OK] gradle-wrapper.jar found
) else (
    echo [FAIL] gradle-wrapper.jar not found
)

if exist "build.gradle.kts" (
    echo [OK] build.gradle.kts found
) else (
    echo [FAIL] build.gradle.kts not found
)

if exist "app\build.gradle.kts" (
    echo [OK] app\build.gradle.kts found
) else (
    echo [FAIL] app\build.gradle.kts not found
)
echo.

echo Checking environment variables...
echo -------------------------------------------------------------------
if defined JAVA_HOME (
    echo [OK] JAVA_HOME = %JAVA_HOME%
) else (
    echo [INFO] JAVA_HOME not set (optional)
)

if defined GRADLE_USER_HOME (
    echo [OK] GRADLE_USER_HOME = %GRADLE_USER_HOME%
) else (
    echo [INFO] GRADLE_USER_HOME not set (will use default)
)

if defined ANDROID_HOME (
    echo [OK] ANDROID_HOME = %ANDROID_HOME%
) else (
    echo [INFO] ANDROID_HOME not set (Gradle will download SDK)
)
echo.

echo Checking disk space...
echo -------------------------------------------------------------------
for /f "tokens=3" %%a in ('dir /-c ^| find "bytes free"') do set FREE=%%a
echo Free space on current drive: %FREE% bytes
echo.

echo Checking internet connectivity...
echo -------------------------------------------------------------------
ping -n 1 8.8.8.8 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [OK] Internet connection available
) else (
    echo [FAIL] No internet connection detected
    echo        First build requires internet to download dependencies
)
echo.

echo Testing Gradle wrapper...
echo -------------------------------------------------------------------
echo Running: gradlew.bat --version
echo.
call gradlew.bat --version 2>&1
echo.
if %ERRORLEVEL% EQU 0 (
    echo [OK] Gradle wrapper works
) else (
    echo [FAIL] Gradle wrapper test failed
)
echo.

echo ===================================================================
echo   Diagnostic Complete
echo ===================================================================
echo.
echo If all checks passed, you can run: build-apk-detailed.bat
echo.
pause
