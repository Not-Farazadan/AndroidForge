@echo off
setlocal enabledelayedexpansion

echo.
echo ===================================================================
echo   Premium Reader - APK Builder (Fixed for Special Characters)
echo ===================================================================
echo.

REM Get the directory where this script is located
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM Check if we're in the right directory
if not exist "gradlew.bat" (
    echo ERROR: gradlew.bat not found!
    echo.
    echo Make sure you're running this script from the PremiumReaderApp directory.
    echo Current directory: %CD%
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo [OK] Project directory verified
echo Directory: %CD%
echo.

REM Check Java installation
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Java not found!
    echo.
    echo Please install JDK 17 from: https://adoptium.net/
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo [OK] Java installation found
java -version 2>&1 | findstr /C:"version"
echo.

echo ===================================================================
echo   Starting Build (This will take 5-10 minutes on first run)
echo ===================================================================
echo.
echo What's happening:
echo   1. Downloading Gradle (~100 MB)
echo   2. Downloading Android dependencies (~1-2 GB)
echo   3. Compiling your app
echo   4. Creating APK
echo.
echo Please be patient... DO NOT CLOSE THIS WINDOW!
echo.
echo ===================================================================
echo.

REM Run the build with full output - use the script's directory
call "%SCRIPT_DIR%gradlew.bat" assembleDebug

REM Capture the result
set BUILD_RESULT=%ERRORLEVEL%

echo.
echo ===================================================================
echo   Build Process Finished
echo ===================================================================
echo.

if %BUILD_RESULT% EQU 0 (
    set "APK_PATH=%SCRIPT_DIR%app\build\outputs\apk\debug\app-debug.apk"

    if exist "!APK_PATH!" (
        echo.
        echo ===================================================================
        echo [SUCCESS] APK built successfully!
        echo ===================================================================
        echo.
        echo APK Location: !APK_PATH!
        echo.

        REM Get file size
        for %%A in ("!APK_PATH!") do set SIZE=%%~zA
        set /a SIZE_MB=!SIZE! / 1048576
        echo APK Size: !SIZE_MB! MB
        echo.

        echo Opening APK folder...
        start explorer "%SCRIPT_DIR%app\build\outputs\apk\debug"
        echo.
        echo ===================================================================
        echo You can now install this APK on your Android device!
        echo ===================================================================
    ) else (
        echo [WARNING] Build reported success but APK not found at expected location.
        echo Expected: !APK_PATH!
    )
) else (
    echo.
    echo ===================================================================
    echo [ERROR] Build FAILED with error code: %BUILD_RESULT%
    echo ===================================================================
    echo.
    echo Common issues and solutions:
    echo.
    echo 1. INTERNET CONNECTION:
    echo    - Make sure you have stable internet
    echo    - First build downloads ~2 GB of dependencies
    echo.
    echo 2. DISK SPACE:
    echo    - Need at least 2-3 GB free space
    echo    - Check your E: drive
    echo.
    echo 3. FIREWALL/ANTIVIRUS:
    echo    - May be blocking Gradle downloads
    echo    - Try temporarily disabling
    echo.
    echo 4. PATH WITH SPECIAL CHARACTERS:
    echo    - Your path contains ^& character which can cause issues
    echo    - Try moving project to a simpler path like E:\Projects\PremiumReaderApp
    echo.
    echo Check the error messages above for specific details.
    echo.
)

echo.
echo ===================================================================
echo Press any key to exit...
pause >nul
