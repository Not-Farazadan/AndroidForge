# Premium Reader - Diagnostic Script (PowerShell)
# This will NOT close automatically

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  Premium Reader - Build Environment Diagnostic" -ForegroundColor Cyan
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

# Check Java
Write-Host "Checking Java installation..." -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------"
try {
    $javaVersion = java -version 2>&1 | Out-String
    Write-Host $javaVersion
    Write-Host "[OK] Java is installed" -ForegroundColor Green
} catch {
    Write-Host "[FAIL] Java not found or not in PATH" -ForegroundColor Red
    Write-Host ""
    Write-Host "SOLUTION: Install JDK 17 from https://adoptium.net/" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host ""

# Check project structure
Write-Host "Checking project structure..." -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------"

if (Test-Path "gradlew.bat") {
    Write-Host "[OK] gradlew.bat found" -ForegroundColor Green
} else {
    Write-Host "[FAIL] gradlew.bat not found" -ForegroundColor Red
    Write-Host ""
    Write-Host "Current directory: $(Get-Location)" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

if (Test-Path "gradle\wrapper\gradle-wrapper.jar") {
    Write-Host "[OK] gradle-wrapper.jar found" -ForegroundColor Green
} else {
    Write-Host "[FAIL] gradle-wrapper.jar not found" -ForegroundColor Red
}

if (Test-Path "build.gradle.kts") {
    Write-Host "[OK] build.gradle.kts found" -ForegroundColor Green
} else {
    Write-Host "[FAIL] build.gradle.kts not found" -ForegroundColor Red
}

if (Test-Path "app\build.gradle.kts") {
    Write-Host "[OK] app\build.gradle.kts found" -ForegroundColor Green
} else {
    Write-Host "[FAIL] app\build.gradle.kts not found" -ForegroundColor Red
}
Write-Host ""

# Check environment variables
Write-Host "Checking environment variables..." -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------"
if ($env:JAVA_HOME) {
    Write-Host "[OK] JAVA_HOME = $env:JAVA_HOME" -ForegroundColor Green
} else {
    Write-Host "[INFO] JAVA_HOME not set (optional)" -ForegroundColor Cyan
}

if ($env:GRADLE_USER_HOME) {
    Write-Host "[OK] GRADLE_USER_HOME = $env:GRADLE_USER_HOME" -ForegroundColor Green
} else {
    Write-Host "[INFO] GRADLE_USER_HOME not set (will use default)" -ForegroundColor Cyan
}

if ($env:ANDROID_HOME) {
    Write-Host "[OK] ANDROID_HOME = $env:ANDROID_HOME" -ForegroundColor Green
} else {
    Write-Host "[INFO] ANDROID_HOME not set (Gradle will download SDK)" -ForegroundColor Cyan
}
Write-Host ""

# Check internet
Write-Host "Checking internet connectivity..." -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------"
$ping = Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet
if ($ping) {
    Write-Host "[OK] Internet connection available" -ForegroundColor Green
} else {
    Write-Host "[FAIL] No internet connection detected" -ForegroundColor Red
    Write-Host "       First build requires internet to download dependencies" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "Current directory:" -ForegroundColor Yellow
Write-Host "$(Get-Location)"
Write-Host ""

# Test Gradle wrapper
Write-Host "Testing Gradle wrapper..." -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------"
Write-Host "This might take a moment if Gradle needs to download..." -ForegroundColor Cyan
Write-Host ""

try {
    $gradleOutput = & .\gradlew.bat --version 2>&1 | Out-String
    Write-Host $gradleOutput

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "[OK] Gradle wrapper works!" -ForegroundColor Green
        Write-Host ""
        Write-Host "===================================================================" -ForegroundColor Green
        Write-Host "  ALL CHECKS PASSED! Ready to build APK." -ForegroundColor Green
        Write-Host "===================================================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "Next step: Run build-apk.ps1 to build your APK" -ForegroundColor Cyan
    } else {
        Write-Host "[FAIL] Gradle wrapper test failed" -ForegroundColor Red
    }
} catch {
    Write-Host "[FAIL] Error running Gradle wrapper: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "  Diagnostic Complete" -ForegroundColor Cyan
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ""
Write-Host "*** PRESS ENTER TO EXIT ***" -ForegroundColor Yellow
Read-Host
