@echo off
setlocal enabledelayedexpansion

echo.
echo ═══════════════════════════════════════════════════════════
echo   Premium Reader - APK Builder (No Android Studio)
echo ═══════════════════════════════════════════════════════════
echo.

REM Check if we're in the right directory
if not exist "gradlew.bat" (
    echo ✗ ERROR: gradlew.bat not found!
    echo.
    echo Make sure you're running this script from the PremiumReaderApp directory.
    echo.
    pause
    exit /b 1
)

echo ✓ Project directory verified
echo.

REM Check Java installation
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ✗ ERROR: Java not found!
    echo.
    echo Please install JDK 17 from: https://adoptium.net/
    echo.
    pause
    exit /b 1
)

echo ✓ Java installation found
java -version 2>&1 | findstr /C:"version"
echo.

REM Check for local.properties or ANDROID_HOME
set SDK_FOUND=0

if exist "local.properties" (
    echo ✓ local.properties found
    set SDK_FOUND=1
) else if defined ANDROID_HOME (
    echo ✓ ANDROID_HOME environment variable found
    echo   Location: %ANDROID_HOME%
    set SDK_FOUND=1
) else (
    echo ⚠ Warning: Android SDK not configured
    echo.
    echo You need to either:
    echo   1. Set ANDROID_HOME environment variable, OR
    echo   2. Create local.properties file with: sdk.dir=C:\\path\\to\\Android\\sdk
    echo.
    echo Do you want to continue anyway? The build might fail. (Y/N)
    set /p CONTINUE=
    if /i not "!CONTINUE!"=="Y" (
        echo Build cancelled.
        pause
        exit /b 1
    )
)

echo.
echo ───────────────────────────────────────────────────────────
echo   Starting Build Process
echo ───────────────────────────────────────────────────────────
echo.

REM Clean previous builds
echo [1/3] Cleaning previous builds...
call gradlew.bat clean --quiet
if %ERRORLEVEL% NEQ 0 (
    echo ✗ Clean failed
    pause
    exit /b 1
)
echo ✓ Clean completed
echo.

REM Build debug APK
echo [2/3] Building debug APK (this may take a few minutes)...
echo       Please wait...
echo.
call gradlew.bat assembleDebug

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ✗ Build FAILED!
    echo.
    echo Common issues:
    echo   • Android SDK not found - set ANDROID_HOME or create local.properties
    echo   • Java version mismatch - ensure JDK 17 is installed
    echo   • Network issues - Gradle needs to download dependencies
    echo.
    echo Check the error messages above for details.
    echo.
    pause
    exit /b 1
)

echo.
echo [3/3] Verifying output...

set APK_PATH=app\build\outputs\apk\debug\app-debug.apk

if exist "%APK_PATH%" (
    echo ✓ APK built successfully!
    echo.
    echo ═══════════════════════════════════════════════════════════
    echo   ✓ BUILD COMPLETE!
    echo ═══════════════════════════════════════════════════════════
    echo.
    echo 📦 APK Location:
    echo    %APK_PATH%
    echo.

    REM Get file size
    for %%A in ("%APK_PATH%") do set SIZE=%%~zA
    set /a SIZE_MB=!SIZE! / 1048576
    echo 📊 APK Size: !SIZE_MB! MB
    echo.

    echo 📱 To install on your device:
    echo    Method 1: adb install %APK_PATH%
    echo    Method 2: Copy APK to phone and install manually
    echo.

    echo Opening APK folder...
    start explorer app\build\outputs\apk\debug
) else (
    echo ✗ APK not found at expected location!
    echo    Expected: %APK_PATH%
)

echo.
pause
